
import React from 'react';
import { ChevronRight } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string;
  trend?: string;
  icon: React.ReactNode;
  onAction?: () => void;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, trend, icon, onAction }) => {
  return (
    <div className="bg-white p-8 rounded-[3rem] border border-gray-50 hover:shadow-2xl hover:shadow-gray-200/40 transition-all duration-500 group relative overflow-hidden flex flex-col justify-between min-h-[260px]">
      <div>
        <div className="flex items-center justify-between mb-6">
          <span className="text-[10px] font-black text-gray-300 uppercase tracking-[0.3em]">{title}</span>
          <div className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center text-[#2E2E2E] group-hover:bg-orange-500 group-hover:text-white transition-all duration-500 shadow-sm">
            {icon}
          </div>
        </div>
        
        <div className="space-y-2 relative z-10">
          <h3 className="text-4xl font-black text-[#2E2E2E] tracking-tighter leading-none group-hover:translate-x-1 transition-transform">{value}</h3>
          {trend && (
            <div className="flex items-center gap-2 pt-2">
              <span className={`text-[10px] font-black tracking-widest px-3 py-1 rounded-full ${
                trend.startsWith('+') ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'
              }`}>
                 {trend}
              </span>
              <span className="text-[10px] font-bold text-gray-300 uppercase tracking-tighter">vs mês anterior</span>
            </div>
          )}
        </div>
      </div>

      {onAction && (
        <button 
          onClick={(e) => {
            e.stopPropagation();
            onAction();
          }}
          className="mt-6 flex items-center justify-between w-full pt-4 border-t border-gray-50 text-[10px] font-black text-gray-400 hover:text-orange-600 uppercase tracking-widest transition-colors group/btn"
        >
          <span>Ver detalhes</span>
          <ChevronRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
        </button>
      )}
      
      {/* Subtle Background Mark */}
      <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-gray-50/50 rounded-full blur-3xl group-hover:bg-orange-500/5 transition-all duration-700"></div>
    </div>
  );
};

export default StatCard;
