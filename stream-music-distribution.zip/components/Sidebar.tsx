
import React from 'react';
import { 
  LayoutDashboard, 
  Music, 
  Upload, 
  BarChart3, 
  User, 
  HelpCircle, 
  LogOut,
  X,
  ShieldCheck
} from 'lucide-react';

interface SidebarProps {
  activeView: string;
  setActiveView: (view: string) => void;
  isOpen: boolean;
  onClose: () => void;
  onLogout?: () => void;
  isAdmin?: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView, isOpen, onClose, onLogout, isAdmin }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'catalog', label: 'Catálogo', icon: Music },
    { id: 'upload', label: 'Distribuir Música', icon: Upload },
    { id: 'analytics', label: 'Estatísticas', icon: BarChart3 },
    { id: 'profile', label: 'Perfil Artista', icon: User },
    { id: 'support', label: 'Suporte', icon: HelpCircle },
  ];

  const handleSelect = (id: string) => {
    setActiveView(id);
    onClose();
  };

  return (
    <>
      {/* Overlay */}
      <div 
        className={`fixed inset-0 bg-black/40 backdrop-blur-sm z-[60] transition-opacity duration-300 ${
          isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
      />

      {/* Drawer */}
      <div 
        className={`fixed top-0 left-0 h-screen bg-white w-80 z-[70] transition-transform duration-500 ease-in-out shadow-2xl flex flex-col ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="p-8 flex items-center justify-between border-b border-gray-100">
          <div className="flex flex-col">
            <span className="text-sm font-black tracking-[0.15em] text-[#2E2E2E]">STREAM MUSIC</span>
            <span className="text-[10px] font-bold text-orange-600 tracking-[0.3em]">DISTRIBUTION</span>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-gray-50 rounded-full text-gray-400 hover:text-black transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        <nav className="flex-1 px-4 mt-8 space-y-2">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleSelect(item.id)}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all duration-300 group ${
                activeView === item.id 
                  ? 'bg-[#2E2E2E] text-white shadow-xl shadow-gray-300' 
                  : 'text-gray-500 hover:bg-gray-100 hover:text-[#2E2E2E]'
              }`}
            >
              <item.icon 
                size={22} 
                className={activeView === item.id ? 'text-orange-500' : 'group-hover:text-orange-600 transition-colors'} 
              />
              <span className="font-bold text-sm tracking-tight">{item.label}</span>
            </button>
          ))}
          
          {/* PAINEL ADMIN - SÓ PARA PROPRIETÁRIO */}
          {isAdmin && (
            <div className="pt-6 mt-6 border-t border-gray-100">
              <span className="px-6 text-[10px] font-black text-gray-300 uppercase tracking-widest mb-4 block">Administração</span>
              <button
                onClick={() => handleSelect('admin')}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all duration-300 group ${
                  activeView === 'admin' 
                    ? 'bg-orange-500 text-white shadow-xl shadow-orange-500/20' 
                    : 'text-gray-500 hover:bg-orange-50 hover:text-orange-600'
                }`}
              >
                <ShieldCheck 
                  size={22} 
                  className={activeView === 'admin' ? 'text-white' : 'text-orange-400'} 
                />
                <span className="font-black text-sm tracking-tight">Painel Administrativo</span>
              </button>
            </div>
          )}
        </nav>

        <div className="p-8 border-t border-gray-50">
          <button 
            onClick={onLogout}
            className="w-full flex items-center gap-4 p-4 text-red-500 hover:bg-red-50 rounded-2xl transition-colors font-bold text-sm"
          >
            <LogOut size={22} />
            <span>Sair da Conta</span>
          </button>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
