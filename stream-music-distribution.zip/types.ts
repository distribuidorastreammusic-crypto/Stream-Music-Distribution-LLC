
export enum ReleaseStatus {
  PENDING = 'Em análise',
  APPROVED = 'Aprovado',
  DISTRIBUTED = 'Distribuído',
  REJECTED = 'Rejeitado',
  CORRECTION = 'Correção Solicitada'
}

export interface SupportTicket {
  id: string;
  artistName: string;
  subject: string;
  message: string;
  status: 'Open' | 'Closed';
  date: string;
}

export interface Artist {
  id: string;
  name: string;
  role: 'Main' | 'Featuring' | 'Producer' | 'Composer';
}

export interface Track {
  id: string;
  title: string;
  version?: string;
  mainArtists: string[];
  featuringArtists: string[];
  producers: string[];
  composers: string[];
  genre: string;
  subGenre: string;
  language: string;
  isrc?: string;
  isExplicit: boolean;
  audioUrl?: string;
}

export interface Release {
  id: string;
  title: string;
  artistName: string;
  type: 'Single' | 'EP' | 'Album';
  coverUrl: string;
  tracks: number;
  genre: string;
  releaseDate: string;
  status: ReleaseStatus;
  upc?: string;
  isrc?: string;
}

export interface UserProfile {
  name: string;
  stageName: string;
  email: string;
  bio: string;
  province: string;
  isAdmin: boolean;
  socials: {
    facebook?: string;
    instagram?: string;
    whatsapp?: string;
  };
}
