
import React, { useState, useRef, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './views/Dashboard';
import Catalog from './views/Catalog';
import Upload from './views/Upload';
import Analytics from './views/Analytics';
import Profile from './views/Profile';
import Support from './views/Support';
import Admin from './views/Admin';
import Auth from './views/Auth';
import { Bell, Search, Menu, X, ShieldCheck } from 'lucide-react';
import { ReleaseStatus, SupportTicket, Release } from './types';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const notificationRef = useRef<HTMLDivElement>(null);

  // Estado global dos utilizadores
  const [users, setUsers] = useState([
    { id: 'USR-01', name: 'Anselmo Ralph', email: 'anselmo@bom.com', role: 'Artista', status: 'Ativo', joinDate: '12/05/2023' },
    { id: 'USR-02', name: 'Yola Semedo', email: 'yola@diva.ao', role: 'Label', status: 'Ativo', joinDate: '15/06/2023' },
    { id: 'USR-03', name: 'Puto Português', email: 'puto@semba.ao', role: 'Artista', status: 'Inativo', joinDate: '01/08/2023' },
    { id: 'USR-04', name: 'Gerilson Insrael', email: 'gerilson@hit.ao', role: 'Artista', status: 'Ativo', joinDate: '20/09/2023' },
  ]);

  // Estado global das notificações
  const [notifications, setNotifications] = useState([
    { id: 1, text: "Seu lançamento 'Verão em Luanda' foi aprovado!", time: "2h atrás", unread: true },
    { id: 2, text: "Relatório de royalties de Outubro disponível.", time: "5h atrás", unread: true },
    { id: 3, text: "Bem-vindo à Stream Music Distribution!", time: "1 dia atrás", unread: false },
  ]);

  // Estado global dos tickets de suporte
  const [tickets, setTickets] = useState<SupportTicket[]>([
    { id: 'TK-842', artistName: 'Anselmo Ralph', subject: 'Problema com ISRC', message: 'Não consigo gerar o ISRC para o meu novo álbum.', status: 'Open', date: '24/10/2023' },
    { id: 'TK-901', artistName: 'C4 Pedro', subject: 'Pagamento Pendente', message: 'O meu pagamento do último trimestre ainda não caiu na conta BAI.', status: 'Open', date: '23/10/2023' }
  ]);

  // Estado global dos lançamentos
  const [releases, setReleases] = useState<Release[]>([
    { id: '1', title: 'Galáxia 1', artistName: 'Dji Tafinha', type: 'EP', status: ReleaseStatus.DISTRIBUTED, releaseDate: '10/05/2023', tracks: 5, genre: 'Hip Hop', upc: '859712345678', isrc: 'AO-G12-23-00001', coverUrl: 'https://picsum.photos/seed/rel1/400/400' },
    { id: '2', title: 'O Último Herói', artistName: 'Dji Tafinha', type: 'Single', status: ReleaseStatus.DISTRIBUTED, releaseDate: '22/08/2023', tracks: 1, genre: 'Afro Beat', upc: '859712345679', isrc: 'AO-G12-23-00002', coverUrl: 'https://picsum.photos/seed/rel2/400/400' },
    { id: '3', title: 'Sonho Angolano', artistName: 'Dji Tafinha', type: 'Album', status: ReleaseStatus.APPROVED, releaseDate: '01/12/2023', tracks: 12, genre: 'Semba', upc: '859712345680', isrc: 'AO-G12-23-00003', coverUrl: 'https://picsum.photos/seed/rel3/400/400' },
  ]);

  const handleLogin = (userData: any) => {
    setCurrentUser(userData);
    setIsLoggedIn(true);
    setActiveView('dashboard');
    addNotification(`Bem-vindo de volta, ${userData.name}!`);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentUser(null);
    setActiveView('dashboard');
  };

  const addRelease = (newRelease: any) => {
    setReleases(prev => [newRelease, ...prev]);
    addNotification(`Novo lançamento enviado: ${newRelease.title}`);
    setActiveView('catalog');
  };

  const updateReleaseStatus = (id: string, newStatus: ReleaseStatus) => {
    setReleases(prev => prev.map(r => r.id === id ? { ...r, status: newStatus } : r));
    const rel = releases.find(r => r.id === id);
    if (rel) {
      addNotification(`O status de "${rel.title}" foi alterado para ${newStatus}`);
    }
  };

  const sendArtistFeedback = (releaseId: string, message: string) => {
    const rel = releases.find(r => r.id === releaseId);
    if (rel) {
      addNotification(`Feedback da Curadoria [${rel.title}]: ${message}`);
    }
  };

  const toggleUserStatus = (id: string) => {
    setUsers(prev => prev.map(u => u.id === id ? { ...u, status: u.status === 'Ativo' ? 'Inativo' : 'Ativo' } : u));
    addNotification(`Status do utilizador ${id} atualizado.`);
  };

  const addNotification = (text: string) => {
    const newNotify = {
      id: Date.now(),
      text,
      time: "Agora",
      unread: true
    };
    setNotifications(prev => [newNotify, ...prev]);
  };

  const submitTicket = (subject: string, message: string) => {
    const newTicket: SupportTicket = {
      id: `TK-${Math.floor(Math.random() * 900) + 100}`,
      artistName: currentUser?.name || 'Visitante',
      subject,
      message,
      status: 'Open',
      date: new Date().toLocaleDateString('pt-AO')
    };
    setTickets(prev => [newTicket, ...prev]);
    addNotification(`Seu ticket de suporte "${subject}" foi enviado.`);
  };

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, unread: false })));
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  if (!isLoggedIn) {
    return <Auth onLogin={handleLogin} />;
  }

  const renderView = () => {
    switch (activeView) {
      case 'dashboard': return <Dashboard onNavigate={setActiveView} />;
      case 'catalog': return <Catalog onNavigate={setActiveView} releases={releases} onRemoveRelease={(id) => setReleases(prev => prev.filter(r => r.id !== id))} />;
      case 'upload': return <Upload onAddRelease={addRelease} onNavigate={setActiveView} />;
      case 'analytics': return <Analytics />;
      case 'profile': return <Profile />;
      case 'support': return <Support onSubmitTicket={submitTicket} />;
      case 'admin': return currentUser?.isAdmin ? (
        <Admin 
          releases={releases} 
          tickets={tickets} 
          users={users}
          onUpdateStatus={updateReleaseStatus} 
          onSendFeedback={sendArtistFeedback}
          onToggleUserStatus={toggleUserStatus}
          onCloseTicket={(id) => {
            setTickets(prev => prev.map(t => t.id === id ? {...t, status: 'Closed'} : t));
            addNotification(`Ticket ${id} marcado como resolvido.`);
          }}
        />
      ) : <Dashboard onNavigate={setActiveView} />;
      default: return <Dashboard onNavigate={setActiveView} />;
    }
  };

  return (
    <div className="min-h-screen flex bg-[#F8F8F8] overflow-x-hidden">
      <Sidebar 
        activeView={activeView} 
        setActiveView={setActiveView} 
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        onLogout={handleLogout}
        isAdmin={currentUser?.isAdmin}
      />

      <main className="flex-1 flex flex-col min-h-screen transition-all duration-500">
        <header className="h-20 bg-white/80 backdrop-blur-md border-b border-gray-100 flex items-center justify-between px-6 md:px-12 sticky top-0 z-40">
          <div className="flex items-center gap-6">
             <button onClick={() => setIsSidebarOpen(true)} className="p-3 bg-gray-50 hover:bg-gray-100 text-[#2E2E2E] rounded-2xl transition-all active:scale-90">
               <Menu size={24} />
             </button>
             <div className="hidden md:flex flex-col">
               <span className="text-[10px] font-black text-gray-300 uppercase tracking-widest">Plataforma</span>
               <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-[#2E2E2E] capitalize tracking-tight">{activeView}</span>
                {currentUser?.isAdmin && activeView === 'admin' && <ShieldCheck size={14} className="text-orange-500" />}
               </div>
             </div>
          </div>
          
          <div className="flex items-center gap-4 md:gap-8">
            <div className="hidden lg:flex relative group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-orange-500 transition-colors" size={18} />
              <input type="text" placeholder="Pesquisar catálogo..." className="pl-12 pr-6 py-3 bg-gray-50 border-none rounded-2xl outline-none focus:ring-4 focus:ring-orange-500/5 focus:bg-white text-sm transition-all w-64 xl:w-96 font-medium" />
            </div>
            
            <div className="flex items-center gap-4 md:gap-6 relative" ref={notificationRef}>
              <button onClick={() => { setShowNotifications(!showNotifications); if(!showNotifications) markAllRead(); }} className={`relative p-2.5 transition-colors rounded-xl ${showNotifications ? 'bg-orange-50 text-orange-500' : 'text-gray-400 hover:text-[#2E2E2E] hover:bg-gray-50'}`}>
                <Bell size={22} />
                {notifications.some(n => n.unread) && (
                  <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-orange-500 rounded-full border-2 border-white animate-pulse"></span>
                )}
              </button>

              {showNotifications && (
                <div className="absolute top-full right-0 mt-4 w-80 bg-white rounded-3xl shadow-2xl shadow-gray-200 border border-gray-100 overflow-hidden animate-premium z-50">
                  <div className="p-5 border-b border-gray-50 flex items-center justify-between bg-gray-50/50">
                    <span className="text-xs font-black text-[#2E2E2E] uppercase tracking-widest">Notificações</span>
                    <button onClick={() => setShowNotifications(false)} className="text-gray-400 hover:text-red-500"><X size={16} /></button>
                  </div>
                  <div className="max-h-96 overflow-y-auto custom-scrollbar">
                    {notifications.length > 0 ? notifications.map(n => (
                      <div key={n.id} className="p-4 border-b border-gray-50 hover:bg-gray-50 transition-colors cursor-pointer group">
                        <div className="flex gap-3">
                          <div className={`w-2 h-2 mt-1.5 rounded-full flex-shrink-0 ${n.unread ? 'bg-orange-500' : 'bg-transparent'}`} />
                          <div>
                            <p className="text-xs font-bold text-[#2E2E2E] leading-relaxed group-hover:text-orange-600 transition-colors">{n.text}</p>
                            <p className="text-[10px] font-medium text-gray-400 mt-1">{n.time}</p>
                          </div>
                        </div>
                      </div>
                    )) : (
                      <div className="p-10 text-center">
                        <p className="text-[10px] font-black text-gray-300 uppercase tracking-widest">Nenhuma notificação</p>
                      </div>
                    )}
                  </div>
                </div>
              )}
              
              <div className="flex items-center gap-4 pl-6 border-l border-gray-100 cursor-pointer group" onClick={() => setActiveView('profile')}>
                <div className="text-right hidden sm:block">
                  <p className="text-xs font-black text-[#2E2E2E] group-hover:text-orange-600 transition-colors">{currentUser?.name}</p>
                  <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">
                    {currentUser?.isAdmin ? 'Super Admin' : 'Artista Verificado'}
                  </p>
                </div>
                <div className="w-11 h-11 rounded-full border-2 border-white shadow-lg overflow-hidden group-hover:scale-110 group-hover:border-orange-500 transition-all duration-300">
                  <img src={currentUser?.avatar || "https://picsum.photos/seed/artist/100/100"} alt="Foto" className="w-full h-full object-cover" />
                </div>
              </div>
            </div>
          </div>
        </header>

        <div className="flex-1 px-6 md:px-12 py-8 md:py-12 max-w-[1500px] mx-auto w-full">
          {renderView()}
        </div>

        <footer className="py-12 px-12 border-t border-gray-100 bg-white mt-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex flex-col text-center md:text-left">
              <span className="text-xs font-black text-[#2E2E2E] tracking-[0.2em]">STREAM MUSIC DISTRIBUTION</span>
              <span className="text-[10px] text-gray-400 mt-2 uppercase font-bold tracking-widest">Luanda • Angola • Global Artist Hub</span>
            </div>
            <div className="flex gap-10 text-[10px] font-black text-gray-400 uppercase tracking-widest">
              <a href="#" className="hover:text-orange-500 transition-colors">Termos de Uso</a>
              <a href="#" className="hover:text-orange-500 transition-colors">Privacidade</a>
              <a href="#" className="hover:text-orange-500 transition-colors">Suporte</a>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
};

export default App;
