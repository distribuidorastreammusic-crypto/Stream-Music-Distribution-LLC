
export const GENRES = [
  'Alternativo', 'Afro Beat', 'Funk', 'Hip Hop & R&B', 
  'Jazz', 'Pop', 'Lo-Fi', 'Eletrônica', 'Afro House'
];

export const SUB_GENRES = [
  'Kuduro', 'House', 'Kizomba', 'Semba', 'Tradicional', 
  'Gospel', 'Rap Cia', 'Rap', 'Trap', 'Sungura', 'Rapduro'
];

export const PROVINCES = [
  'Bengo', 'Benguela', 'Bié', 'Cabinda', 'Cuando Cubango', 
  'Cuanza Norte', 'Cuanza Sul', 'Cunene', 'Huambo', 'Huíla', 
  'Luanda', 'Lunda Norte', 'Lunda Sul', 'Malanje', 'Moxico', 
  'Namibe', 'Uíge', 'Zaire'
];

export const PLATFORMS = [
  'Spotify', 'Apple Music', 'Boomplay', 'Audiomack', 'YouTube Music', 
  'Deezer', 'Tidal', 'Amazon Music', 'Napster', 'Pandora', 'Shazam',
  'Anghami', '7digital', 'iHeartRadio', 'Tencent', 'NetEase', 'KKBox',
  'JioSaavn', 'Wynk', 'Yandex', 'Zvooq', 'Qobuz', 'Facebook', 'Instagram',
  'TikTok', 'Peloton', 'Dubset', 'Beatport', 'SoundCloud'
];

export const LANGUAGES = ['Português', 'Inglês', 'Francês', 'Kimbundu', 'Umbundu'];
