
import React, { useState } from 'react';
import { 
  BarChart3, 
  Disc, 
  DollarSign, 
  MessageSquare, 
  Settings, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  ChevronRight, 
  ArrowUpRight, 
  Search, 
  Download, 
  Filter, 
  ShieldCheck, 
  Music, 
  CreditCard, 
  Loader2, 
  Lock, 
  Globe, 
  RefreshCw,
  Edit3,
  X,
  Save,
  Eye,
  Calendar,
  Layers,
  MessageSquareText,
  Send
} from 'lucide-react';
import { ReleaseStatus, SupportTicket, Release } from '../types';

interface AdminProps {
  releases: Release[];
  tickets: SupportTicket[];
  users: any[];
  onUpdateStatus: (id: string, status: ReleaseStatus) => void;
  onSendFeedback: (releaseId: string, message: string) => void;
  onToggleUserStatus: (id: string) => void;
  onCloseTicket: (id: string) => void;
}

const Admin: React.FC<AdminProps> = ({ releases, tickets, users, onUpdateStatus, onSendFeedback, onToggleUserStatus, onCloseTicket }) => {
  const [currentTab, setCurrentTab] = useState('dashboard');
  const [isConsolidating, setIsConsolidating] = useState(false);
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [editingRelease, setEditingRelease] = useState<Release | null>(null);
  const [feedbackRelease, setFeedbackRelease] = useState<Release | null>(null);
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [isSendingFeedback, setIsSendingFeedback] = useState(false);
  const [isSavingEdit, setIsSavingEdit] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [commission, setCommission] = useState(15);
  const [autoIsrc, setAutoIsrc] = useState(true);

  const filteredReleases = releases.filter(r => 
    r.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    r.artistName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const pendingReleases = releases.filter(r => r.status === ReleaseStatus.PENDING);
  const openTickets = tickets.filter(t => t.status === 'Open');

  const stats = [
    { id: 'dashboard', label: 'Artistas Totais', value: users.length.toString(), trend: '+12%', icon: <Globe size={20} /> },
    { id: 'releases', label: 'Obras no Catálogo', value: releases.length.toString(), trend: '+5%', icon: <Music size={20} /> },
    { id: 'royalties', label: 'Receita Total', value: '2.450.000 Kz', trend: '+18%', icon: <DollarSign size={20} /> },
    { id: 'dashboard', label: 'Streams Totais', value: '12.8M', trend: '+24%', icon: <BarChart3 size={20} /> },
  ];

  const menu = [
    { id: 'dashboard', label: 'Visão Geral', icon: BarChart3 },
    { id: 'releases', label: 'Lançamentos', icon: Disc, count: pendingReleases.length },
    { id: 'royalties', label: 'Financeiro', icon: DollarSign },
    { id: 'tickets', label: 'Suporte', icon: MessageSquare, count: openTickets.length },
    { id: 'settings', label: 'Configurações', icon: Settings },
  ];

  const handleConsolidate = () => {
    setIsConsolidating(true);
    setTimeout(() => {
      setIsConsolidating(false);
      alert("Relatórios financeiros consolidados e enviados para processamento bancário.");
    }, 2000);
  };

  const handleSaveSettings = () => {
    setIsSavingSettings(true);
    setTimeout(() => {
      setIsSavingSettings(false);
      alert("Configurações do sistema atualizadas com sucesso.");
    }, 1500);
  };

  const handleSaveReleaseEdit = () => {
    setIsSavingEdit(true);
    setTimeout(() => {
      setIsSavingEdit(false);
      setEditingRelease(null);
      alert("Dados do lançamento atualizados com sucesso.");
    }, 1000);
  };

  const handleSendFeedbackAction = () => {
    if (!feedbackRelease || !feedbackMessage.trim()) return;
    setIsSendingFeedback(true);
    setTimeout(() => {
      onSendFeedback(feedbackRelease.id, feedbackMessage);
      setIsSendingFeedback(false);
      setFeedbackRelease(null);
      setFeedbackMessage('');
      alert("Mensagem enviada com sucesso ao artista.");
    }, 1000);
  };

  return (
    <div className="animate-premium flex flex-col xl:flex-row gap-6 md:gap-10">
      <div className="w-full xl:w-64 space-y-1.5">
        <div className="p-5 bg-[#2E2E2E] rounded-[2rem] text-white mb-4">
          <div className="flex items-center gap-3">
             <div className="w-9 h-9 bg-orange-500 rounded-xl flex items-center justify-center">
               <ShieldCheck size={18} />
             </div>
             <div>
               <h2 className="text-[11px] font-black uppercase tracking-widest">Painel Admin</h2>
               <p className="text-[8px] text-gray-400 font-bold uppercase tracking-tighter">Super Proprietário</p>
             </div>
          </div>
        </div>

        {menu.map(item => (
          <button
            key={item.id}
            onClick={() => setCurrentTab(item.id)}
            className={`w-full flex items-center justify-between p-3.5 rounded-xl transition-all duration-300 group ${
              currentTab === item.id ? 'bg-white text-orange-600 shadow-lg shadow-gray-200/50' : 'text-gray-400 hover:bg-white/50 hover:text-black'
            }`}
          >
            <div className="flex items-center gap-3">
              <item.icon size={18} className={currentTab === item.id ? 'text-orange-500' : 'group-hover:text-orange-500'} />
              <span className="text-[10px] font-black uppercase tracking-widest">{item.label}</span>
            </div>
            {item.count && item.count > 0 && (
              <span className="bg-orange-500 text-white text-[8px] font-black px-1.5 py-0.5 rounded-full">{item.count}</span>
            )}
          </button>
        ))}
      </div>

      <div className="flex-1 space-y-8 pb-20">
        {currentTab === 'dashboard' && (
          <div className="space-y-8 animate-premium">
             <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
                {stats.map(s => (
                  <div key={s.label} onClick={() => setCurrentTab(s.id)} className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm group cursor-pointer hover:-translate-y-1 transition-transform">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-[9px] font-black text-gray-300 uppercase tracking-widest">{s.label}</span>
                      <div className="text-gray-400 group-hover:text-orange-500 transition-colors">{s.icon}</div>
                    </div>
                    <div className="flex items-baseline gap-2">
                      <h4 className="text-xl font-black text-[#2E2E2E] tracking-tighter">{s.value}</h4>
                      <span className="text-[9px] font-bold text-green-500">{s.trend}</span>
                    </div>
                  </div>
                ))}
             </div>

             <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm p-8">
                   <div className="flex items-center justify-between mb-8">
                      <h3 className="text-lg font-black text-[#2E2E2E] uppercase tracking-tighter">Lançamentos Pendentes</h3>
                      <button onClick={() => setCurrentTab('releases')} className="text-[9px] font-black text-orange-600 uppercase tracking-widest border-b border-orange-100">Ver Tudo</button>
                   </div>
                   <div className="space-y-3">
                      {pendingReleases.length > 0 ? pendingReleases.slice(0, 4).map(rel => (
                        <div key={rel.id} className="flex items-center justify-between p-4 bg-gray-50/50 rounded-2xl border border-gray-100 hover:bg-gray-50 transition-colors">
                           <div className="flex items-center gap-3">
                             <div className="w-10 h-10 rounded-xl overflow-hidden bg-gray-200">
                               <img src={rel.coverUrl} className="w-full h-full object-cover" />
                             </div>
                             <div>
                               <p className="text-xs font-black text-[#2E2E2E] leading-tight">{rel.title}</p>
                               <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">{rel.artistName}</p>
                             </div>
                           </div>
                           <button onClick={() => { setEditingRelease(rel); setCurrentTab('releases'); }} className="p-2.5 bg-white text-orange-500 rounded-lg shadow-sm hover:scale-110 transition-transform">
                             <Edit3 size={16} />
                           </button>
                        </div>
                      )) : (
                        <div className="py-16 text-center">
                          <CheckCircle2 size={32} className="mx-auto text-green-200 mb-3" />
                          <p className="text-[9px] font-black text-gray-300 uppercase tracking-widest">Tudo em dia!</p>
                        </div>
                      )}
                   </div>
                </div>

                <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm p-8">
                   <div className="flex items-center justify-between mb-8">
                      <h3 className="text-lg font-black text-[#2E2E2E] uppercase tracking-tighter">Suporte Recente</h3>
                      <button onClick={() => setCurrentTab('tickets')} className="text-[9px] font-black text-orange-600 uppercase tracking-widest border-b border-orange-100">Gestão Suporte</button>
                   </div>
                   <div className="space-y-3">
                      {openTickets.length > 0 ? openTickets.slice(0, 4).map(ticket => (
                        <div key={ticket.id} className="p-4 bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all">
                           <div className="flex items-center justify-between mb-2">
                              <span className="text-[8px] font-black text-orange-500 uppercase tracking-widest bg-orange-50 px-2 py-0.5 rounded-full">{ticket.id}</span>
                              <span className="text-[8px] font-bold text-gray-300">{ticket.date}</span>
                           </div>
                           <h5 className="text-[11px] font-black text-[#2E2E2E] truncate">{ticket.subject}</h5>
                           <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-50">
                              <p className="text-[9px] font-bold text-gray-400 uppercase tracking-tighter">{ticket.artistName}</p>
                              <button onClick={() => setCurrentTab('tickets')} className="text-[8px] font-black text-blue-500 uppercase tracking-widest hover:underline">Atender</button>
                           </div>
                        </div>
                      )) : (
                        <div className="py-16 text-center">
                          <CheckCircle2 size={32} className="mx-auto text-green-200 mb-3" />
                          <p className="text-[9px] font-black text-gray-300 uppercase tracking-widest">Nenhum ticket aberto</p>
                        </div>
                      )}
                   </div>
                </div>
             </div>
          </div>
        )}

        {currentTab === 'releases' && (
          <div className="animate-premium space-y-8">
             <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div>
                  <h3 className="text-3xl font-black text-[#2E2E2E] tracking-tighter">Curadoria de Conteúdo</h3>
                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-1">Gere aprovações e revisões de obras</p>
                </div>
                <div className="flex gap-3">
                   <div className="relative">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                      <input 
                        type="text" 
                        placeholder="Pesquisar obra ou artista..." 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-12 pr-6 py-3.5 bg-white border-transparent rounded-[1.25rem] outline-none font-bold text-xs shadow-xl shadow-gray-200/50 w-full md:w-80 transition-all focus:ring-4 focus:ring-orange-500/5" 
                      />
                   </div>
                   <button className="p-3.5 bg-white rounded-[1.25rem] text-gray-400 shadow-xl shadow-gray-200/50 hover:text-orange-500 transition-all">
                     <Filter size={20} />
                   </button>
                </div>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 2xl:grid-cols-3 gap-6">
                {filteredReleases.map(rel => (
                  <div key={rel.id} className="bg-white p-6 rounded-[2.5rem] border border-gray-50 shadow-sm hover:shadow-2xl hover:shadow-gray-200/40 transition-all duration-500 group flex flex-col">
                    <div className="flex gap-5 mb-6">
                      <div className="w-24 h-24 rounded-[1.5rem] overflow-hidden shadow-lg flex-shrink-0 relative">
                        <img src={rel.coverUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                        <div className={`absolute top-2 right-2 w-3 h-3 rounded-full border-2 border-white shadow-sm ${
                           rel.status === ReleaseStatus.DISTRIBUTED ? 'bg-green-500' :
                           rel.status === ReleaseStatus.APPROVED ? 'bg-green-400' :
                           rel.status === ReleaseStatus.REJECTED ? 'bg-red-500' :
                           rel.status === ReleaseStatus.PENDING ? 'bg-orange-500' : 'bg-gray-400'
                        }`} />
                      </div>
                      <div className="flex-1 min-w-0 py-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[8px] font-black text-gray-300 uppercase tracking-widest">{rel.type}</span>
                          <span className="text-[8px] font-black text-orange-500 uppercase tracking-widest bg-orange-50 px-2 py-0.5 rounded-full">{rel.id}</span>
                        </div>
                        <h4 className="text-base font-black text-[#2E2E2E] tracking-tight truncate leading-tight group-hover:text-orange-600 transition-colors">{rel.title}</h4>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest truncate mt-0.5">{rel.artistName}</p>
                        
                        <div className="flex items-center gap-4 mt-3">
                          <div className="flex items-center gap-1.5">
                            <Calendar size={12} className="text-gray-300" />
                            <span className="text-[9px] font-black text-gray-400 uppercase">{rel.releaseDate}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Layers size={12} className="text-gray-300" />
                            <span className="text-[9px] font-black text-gray-400 uppercase">{rel.genre}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 mt-auto">
                       <button 
                         onClick={() => onUpdateStatus(rel.id, ReleaseStatus.APPROVED)}
                         className="flex items-center justify-center gap-2 px-4 py-3 bg-green-50 text-green-600 rounded-2xl hover:bg-green-600 hover:text-white transition-all shadow-sm"
                       >
                         <CheckCircle2 size={14} />
                         <span className="text-[9px] font-black uppercase tracking-widest">Aprovar</span>
                       </button>

                       <button 
                         onClick={() => onUpdateStatus(rel.id, ReleaseStatus.REJECTED)}
                         className="flex items-center justify-center gap-2 px-4 py-3 bg-red-50 text-red-600 rounded-2xl hover:bg-red-600 hover:text-white transition-all shadow-sm"
                       >
                         <XCircle size={14} />
                         <span className="text-[9px] font-black uppercase tracking-widest">Rejeitar</span>
                       </button>

                       <button 
                         onClick={() => onUpdateStatus(rel.id, ReleaseStatus.PENDING)}
                         className="flex items-center justify-center gap-2 px-4 py-3 bg-yellow-50 text-yellow-600 rounded-2xl hover:bg-yellow-500 hover:text-white transition-all shadow-sm"
                       >
                         <RefreshCw size={14} />
                         <span className="text-[9px] font-black uppercase tracking-widest">Análise</span>
                       </button>

                       <button 
                         onClick={() => setEditingRelease(rel)}
                         className="flex items-center justify-center gap-2 px-4 py-3 bg-[#2E2E2E] text-white rounded-2xl hover:bg-black transition-all shadow-sm"
                       >
                         <Edit3 size={14} />
                         <span className="text-[9px] font-black uppercase tracking-widest">Editar</span>
                       </button>

                       <button 
                         onClick={() => setFeedbackRelease(rel)}
                         className="col-span-2 flex items-center justify-center gap-2 px-4 py-3 bg-orange-50 text-orange-600 rounded-2xl hover:bg-orange-600 hover:text-white transition-all shadow-sm mt-1"
                       >
                         <MessageSquareText size={14} />
                         <span className="text-[9px] font-black uppercase tracking-widest">Dar Feedback / Mensagem</span>
                       </button>
                    </div>
                  </div>
                ))}
             </div>

             {filteredReleases.length === 0 && (
               <div className="py-32 text-center bg-white rounded-[4rem] border border-dashed border-gray-200">
                 <Disc size={48} className="mx-auto text-gray-100 mb-6" />
                 <h3 className="text-xl font-black text-gray-300 uppercase tracking-widest">Nenhuma obra encontrada</h3>
               </div>
             )}
          </div>
        )}

        {currentTab === 'tickets' && (
          <div className="animate-premium space-y-8">
             <div className="flex items-center justify-between">
                <h3 className="text-2xl font-black text-[#2E2E2E] tracking-tighter">Central de Tickets</h3>
                <span className="bg-orange-500 text-white text-[9px] font-black px-3 py-1.5 rounded-xl uppercase tracking-widest shadow-lg shadow-orange-500/20">{openTickets.length} Abertos</span>
             </div>

             <div className="grid grid-cols-1 gap-4">
                {tickets.map(ticket => (
                  <div key={ticket.id} className={`bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm transition-all ${ticket.status === 'Closed' ? 'opacity-60 grayscale' : 'hover:shadow-xl hover:shadow-gray-200/50'}`}>
                     <div className="flex items-center justify-between mb-6">
                        <div className="flex items-center gap-4">
                           <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${ticket.status === 'Open' ? 'bg-orange-50 text-orange-500' : 'bg-gray-100 text-gray-400'}`}>
                             <MessageSquare size={20} />
                           </div>
                           <div>
                             <span className="text-[9px] font-black text-gray-300 uppercase tracking-widest">Protocolo {ticket.id}</span>
                             <h4 className="text-lg font-black text-[#2E2E2E] tracking-tighter mt-0.5">{ticket.subject}</h4>
                           </div>
                        </div>
                        <div className="text-right">
                           <p className="text-xs font-black text-[#2E2E2E] uppercase tracking-tighter">{ticket.artistName}</p>
                           <p className="text-[8px] font-bold text-gray-400 uppercase mt-0.5">Em {ticket.date}</p>
                        </div>
                     </div>
                     
                     <div className="p-6 bg-gray-50 rounded-2xl border border-gray-100 mb-6">
                        <p className="text-xs text-gray-600 font-medium leading-relaxed italic">"{ticket.message}"</p>
                     </div>

                     <div className="flex items-center justify-between pt-6 border-t border-gray-50">
                        <div className="flex gap-3">
                           <a 
                             href={`https://wa.me/244957729023?text=Olá, sou do Suporte Stream Music Angola sobre o ticket ${ticket.id}`} 
                             target="_blank" 
                             rel="noreferrer"
                             className="px-6 py-3 bg-green-500 text-white rounded-xl text-[9px] font-black uppercase tracking-widest shadow-lg shadow-green-500/20 hover:scale-105 transition-all"
                           >
                             Atender WhatsApp
                           </a>
                           {ticket.status === 'Open' && (
                             <button 
                               onClick={() => onCloseTicket(ticket.id)}
                               className="px-6 py-3 bg-gray-50 text-gray-400 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-red-50 hover:text-red-500 transition-all"
                             >
                               Fechar Ticket
                             </button>
                           )}
                        </div>
                     </div>
                  </div>
                ))}
             </div>
          </div>
        )}

        {currentTab === 'royalties' && (
          <div className="animate-premium space-y-8">
             <div className="flex items-center justify-between">
                <h3 className="text-2xl font-black text-[#2E2E2E] tracking-tighter">Financeiro & Royalties</h3>
                <button 
                  onClick={handleConsolidate}
                  disabled={isConsolidating}
                  className="flex items-center gap-2 px-6 py-3 bg-[#2E2E2E] text-white rounded-xl text-[9px] font-black uppercase tracking-widest shadow-xl shadow-black/10 transition-all active:scale-95"
                >
                  {isConsolidating ? <Loader2 size={14} className="animate-spin" /> : <Download size={14} />}
                  {isConsolidating ? 'Consolidando...' : 'Consolidar Relatórios'}
                </button>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-[#2E2E2E] p-8 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden group">
                   <div className="relative z-10">
                      <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest">Comissão ({commission}%)</span>
                      <h4 className="text-3xl font-black mt-3 tracking-tighter">367.500 Kz</h4>
                      <p className="text-[8px] font-bold text-gray-400 uppercase mt-3 tracking-widest flex items-center gap-1.5">
                        <ArrowUpRight size={12} className="text-green-500" /> +12%
                      </p>
                   </div>
                   <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-orange-500/10 rounded-full blur-3xl group-hover:scale-150 transition-all duration-1000"></div>
                </div>

                <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm">
                   <span className="text-[9px] font-black text-gray-300 uppercase tracking-widest">Pendentes Artistas</span>
                   <h4 className="text-2xl font-black mt-3 text-[#2E2E2E] tracking-tighter">842.100 Kz</h4>
                   <button className="mt-6 text-[8px] font-black text-orange-600 uppercase tracking-[0.2em] border-b border-orange-200 pb-1">Ver Fila</button>
                </div>

                <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm">
                   <span className="text-[9px] font-black text-gray-300 uppercase tracking-widest">Top País Receita</span>
                   <h4 className="text-2xl font-black mt-3 text-[#2E2E2E] tracking-tighter">Angola (62%)</h4>
                   <div className="w-full bg-gray-100 h-1.5 rounded-full mt-6">
                     <div className="bg-orange-500 h-full w-[62%] rounded-full"></div>
                   </div>
                </div>
             </div>

             <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm p-8">
                <div className="flex items-center justify-between mb-6">
                  <h4 className="text-lg font-black text-[#2E2E2E] uppercase tracking-tighter">Fila de Processamento</h4>
                  <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">3 Transações</span>
                </div>
                <div className="space-y-3">
                   {[
                     { user: 'Gerilson Insrael', val: '140.200 Kz', date: 'Hoje', status: 'Processando', method: 'BAI Transfer' },
                     { user: 'Anna Joyce', val: '89.500 Kz', date: 'Ontem', status: 'Processando', method: 'Express' },
                     { user: 'Preto Show', val: '230.000 Kz', date: '22 Out', status: 'Aguardando', method: 'BIC Swift' },
                   ].map((t, idx) => (
                     <div key={idx} className="flex flex-col md:flex-row md:items-center justify-between p-4 bg-gray-50/50 rounded-2xl border border-gray-100 gap-3 group hover:bg-white hover:border-orange-100 transition-all">
                        <div className="flex items-center gap-4">
                           <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-orange-500 shadow-sm"><CreditCard size={18} /></div>
                           <div>
                              <p className="text-xs font-black text-[#2E2E2E]">{t.user}</p>
                              <p className="text-[8px] font-bold text-gray-400 uppercase tracking-widest">{t.method}</p>
                           </div>
                        </div>
                        <div className="flex items-center justify-between md:justify-end gap-6">
                           <div className="text-right">
                              <span className="text-[11px] font-black text-[#2E2E2E] block">{t.val}</span>
                              <span className="text-[7px] font-bold text-gray-400 uppercase tracking-tighter">{t.date}</span>
                           </div>
                           <button className="px-4 py-2 bg-white text-[#2E2E2E] border border-gray-100 rounded-lg text-[7px] font-black uppercase tracking-widest group-hover:bg-[#2E2E2E] group-hover:text-white transition-all shadow-sm">Pagar</button>
                        </div>
                     </div>
                   ))}
                </div>
             </div>
          </div>
        )}

        {currentTab === 'settings' && (
          <div className="animate-premium space-y-8">
             <div className="flex items-center justify-between">
                <h3 className="text-2xl font-black text-[#2E2E2E] tracking-tighter">Configurações</h3>
                <button 
                  onClick={handleSaveSettings}
                  disabled={isSavingSettings}
                  className="px-8 py-3 bg-orange-500 text-white rounded-xl text-[9px] font-black uppercase tracking-widest shadow-xl shadow-orange-500/20 active:scale-95 transition-all"
                >
                  {isSavingSettings ? <Loader2 size={14} className="animate-spin" /> : 'Guardar'}
                </button>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm space-y-6">
                   <div className="flex items-center gap-3 mb-1">
                      <div className="p-2.5 bg-orange-50 text-orange-600 rounded-xl"><DollarSign size={18} /></div>
                      <h4 className="text-[11px] font-black text-[#2E2E2E] uppercase tracking-widest">Taxas</h4>
                   </div>
                   <div className="space-y-3">
                      <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-3">Comissão (%)</label>
                      <input 
                        type="number" 
                        value={commission}
                        onChange={(e) => setCommission(parseInt(e.target.value))}
                        className="w-full px-6 py-4 bg-gray-50 rounded-xl outline-none font-bold text-xs focus:bg-white border-transparent focus:border-orange-100 transition-all shadow-inner"
                      />
                   </div>
                </div>

                <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm space-y-6">
                   <div className="flex items-center gap-3 mb-1">
                      <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl"><Globe size={18} /></div>
                      <h4 className="text-[11px] font-black text-[#2E2E2E] uppercase tracking-widest">Automação</h4>
                   </div>
                   <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                      <div>
                         <h5 className="text-[10px] font-black text-[#2E2E2E] uppercase tracking-widest">ISRC Auto</h5>
                         <p className="text-[8px] font-bold text-gray-400 uppercase tracking-tighter mt-0.5">Prefixo AO-SMC</p>
                      </div>
                      <button 
                        onClick={() => setAutoIsrc(!autoIsrc)}
                        className={`w-12 h-6.5 rounded-full relative transition-all ${autoIsrc ? 'bg-orange-500' : 'bg-gray-300'}`}
                      >
                         <div className={`absolute top-0.5 w-5.5 h-5.5 bg-white rounded-full shadow-sm transition-all ${autoIsrc ? 'left-6' : 'left-0.5'}`} />
                      </button>
                   </div>
                </div>

                <div className="bg-[#2E2E2E] p-10 rounded-[2.5rem] text-white md:col-span-2 shadow-2xl overflow-hidden relative group">
                   <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
                      <div className="space-y-3 max-w-sm">
                         <div className="flex items-center gap-3">
                            <Lock size={18} className="text-orange-500" />
                            <h4 className="text-lg font-black uppercase tracking-tighter">Segurança</h4>
                         </div>
                         <p className="text-gray-400 text-xs leading-relaxed">Ações registadas para auditoria e conformidade.</p>
                      </div>
                      <button className="px-8 py-4 bg-white text-[#2E2E2E] rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-orange-500 hover:text-white transition-all shadow-xl">Ver Logs</button>
                   </div>
                   <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-orange-500/10 rounded-full blur-3xl group-hover:scale-150 transition-all duration-1000"></div>
                </div>
             </div>
          </div>
        )}

      </div>

      {/* MODAL DE ENVIO DE FEEDBACK/MENSAGEM */}
      {feedbackRelease && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-[#2E2E2E]/90 backdrop-blur-lg" onClick={() => setFeedbackRelease(null)} />
          <div className="relative bg-white w-full max-w-xl rounded-[3rem] shadow-2xl overflow-hidden animate-premium">
             <div className="p-8 md:p-10">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-orange-50 text-orange-600 rounded-2xl flex items-center justify-center">
                      <MessageSquareText size={24} />
                    </div>
                    <div>
                      <h3 className="text-xl font-black text-[#2E2E2E] tracking-tighter">Enviar Feedback</h3>
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Para: {feedbackRelease.artistName}</p>
                    </div>
                  </div>
                  <button onClick={() => setFeedbackRelease(null)} className="p-2 hover:bg-gray-100 rounded-xl text-gray-400"><X size={20} /></button>
                </div>

                <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100 mb-6 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl overflow-hidden shadow-sm flex-shrink-0">
                    <img src={feedbackRelease.coverUrl} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-[#2E2E2E]">{feedbackRelease.title}</h4>
                    <span className="text-[9px] font-bold text-orange-500 uppercase px-2 py-0.5 bg-orange-50 rounded-full">{feedbackRelease.status}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-4">Sua Mensagem / Instruções de Correção</label>
                  <textarea 
                    rows={6}
                    value={feedbackMessage}
                    onChange={(e) => setFeedbackMessage(e.target.value)}
                    placeholder="Escreva aqui o feedback detalhado. O artista verá isto no sino de notificações..."
                    className="w-full px-8 py-6 bg-gray-50 rounded-[2rem] border-transparent focus:bg-white focus:border-orange-100 outline-none font-bold text-xs transition-all shadow-inner resize-none custom-scrollbar"
                  />
                </div>

                <button 
                  onClick={handleSendFeedbackAction}
                  disabled={isSendingFeedback || !feedbackMessage.trim()}
                  className="w-full mt-8 py-6 bg-[#2E2E2E] text-white rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest shadow-xl shadow-black/10 active:scale-95 transition-all flex items-center justify-center gap-3 hover:bg-black disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSendingFeedback ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
                  {isSendingFeedback ? 'A Enviar...' : 'Enviar Mensagem Agora'}
                </button>
             </div>
          </div>
        </div>
      )}

      {/* MODAL DE EDIÇÃO DE LANÇAMENTO */}
      {editingRelease && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8">
          <div className="absolute inset-0 bg-[#2E2E2E]/80 backdrop-blur-md" onClick={() => setEditingRelease(null)} />
          <div className="relative bg-white w-full max-w-5xl rounded-[3rem] shadow-2xl overflow-hidden flex flex-col md:flex-row max-h-[90vh] animate-premium">
            <div className="w-full md:w-1/3 bg-gray-100 relative group overflow-hidden">
               <img src={editingRelease.coverUrl} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
               <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <Eye size={32} className="text-white" />
               </div>
            </div>
            
            <div className="flex-1 p-8 md:p-12 overflow-y-auto custom-scrollbar flex flex-col">
               <div className="flex items-center justify-between mb-10">
                  <div>
                    <span className="text-[10px] font-black text-orange-500 uppercase tracking-widest block mb-2">Editor Administrativo</span>
                    <h2 className="text-4xl font-black text-[#2E2E2E] tracking-tighter leading-tight">Editar Lançamento</h2>
                  </div>
                  <button onClick={() => setEditingRelease(null)} className="p-3 bg-gray-50 text-gray-400 rounded-2xl hover:text-red-500 hover:bg-red-50 transition-all"><X size={24} /></button>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-3">Título da Obra</label>
                    <input 
                      type="text" 
                      defaultValue={editingRelease.title} 
                      className="w-full px-6 py-4 bg-gray-50 rounded-2xl border-transparent focus:bg-white focus:border-orange-100 outline-none font-bold text-sm shadow-inner transition-all" 
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-3">Artista Principal</label>
                    <input 
                      type="text" 
                      defaultValue={editingRelease.artistName} 
                      className="w-full px-6 py-4 bg-gray-50 rounded-2xl border-transparent focus:bg-white focus:border-orange-100 outline-none font-bold text-sm shadow-inner transition-all" 
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-3">Gênero Musical</label>
                    <input 
                      type="text" 
                      defaultValue={editingRelease.genre} 
                      className="w-full px-6 py-4 bg-gray-50 rounded-2xl border-transparent focus:bg-white focus:border-orange-100 outline-none font-bold text-sm shadow-inner transition-all" 
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-3">UPC Code</label>
                    <input 
                      type="text" 
                      defaultValue={editingRelease.upc} 
                      className="w-full px-6 py-4 bg-gray-50 rounded-2xl border-transparent focus:bg-white focus:border-orange-100 outline-none font-mono font-bold text-sm shadow-inner transition-all" 
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-3">ISRC Code</label>
                    <input 
                      type="text" 
                      defaultValue={editingRelease.isrc} 
                      className="w-full px-6 py-4 bg-gray-50 rounded-2xl border-transparent focus:bg-white focus:border-orange-100 outline-none font-mono font-bold text-sm shadow-inner transition-all" 
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-3">Data de Lançamento</label>
                    <input 
                      type="text" 
                      defaultValue={editingRelease.releaseDate} 
                      className="w-full px-6 py-4 bg-gray-50 rounded-2xl border-transparent focus:bg-white focus:border-orange-100 outline-none font-bold text-sm shadow-inner transition-all" 
                    />
                  </div>
               </div>

               <div className="mt-auto flex flex-col md:flex-row gap-4 pt-10 border-t border-gray-50">
                  <button 
                    onClick={handleSaveReleaseEdit}
                    disabled={isSavingEdit}
                    className="flex-1 flex items-center justify-center gap-3 py-6 bg-[#2E2E2E] text-white rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest shadow-xl shadow-black/10 active:scale-95 transition-all"
                  >
                    {isSavingEdit ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                    {isSavingEdit ? 'A Guardar...' : 'Guardar Alterações'}
                  </button>
                  <div className="flex gap-4">
                    <button 
                      onClick={() => { onUpdateStatus(editingRelease.id, ReleaseStatus.APPROVED); setEditingRelease(null); }}
                      className="px-8 py-6 bg-green-500 text-white rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest shadow-xl shadow-green-500/20 active:scale-95 transition-all"
                    >
                      Aprovar Agora
                    </button>
                    <button 
                      onClick={() => { onUpdateStatus(editingRelease.id, ReleaseStatus.REJECTED); setEditingRelease(null); }}
                      className="px-8 py-6 bg-red-50 text-red-500 border border-red-100 rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest hover:bg-red-500 hover:text-white transition-all active:scale-95"
                    >
                      Rejeitar
                    </button>
                  </div>
               </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Admin;
