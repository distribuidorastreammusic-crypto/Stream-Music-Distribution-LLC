
import React from 'react';
import { PlayCircle, DollarSign, ListMusic, TrendingUp, Upload, ChevronRight, ArrowUpRight, Globe } from 'lucide-react';
import StatCard from '../components/StatCard';
import { ReleaseStatus } from '../types';

interface DashboardProps {
  onNavigate: (view: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const recentReleases = [
    { id: '1', title: 'Verão em Luanda', artist: 'Dji Tafinha', status: ReleaseStatus.DISTRIBUTED, date: '12 Out 2023', streams: '450.2k' },
    { id: '2', title: 'Kizomba Mix Vol. 1', artist: 'Yola Semedo', status: ReleaseStatus.APPROVED, date: '15 Nov 2023', streams: '---' },
    { id: '3', title: 'Novo Beat (Single)', artist: 'C4 Pedro', status: ReleaseStatus.PENDING, date: '20 Dez 2023', streams: '---' },
  ];

  const goToAnalytics = () => onNavigate('analytics');

  return (
    <div className="space-y-12 md:space-y-16 animate-premium">
      {/* Hero Section */}
      <header className="flex flex-col gap-3">
        <h1 className="text-5xl md:text-7xl font-black text-[#2E2E2E] tracking-tighter leading-tight md:leading-none">
          Olá, Dji Tafinha.
        </h1>
        <div className="flex flex-col md:flex-row md:items-center gap-4 mt-1">
          <p className="text-gray-400 text-base md:text-lg font-medium">Sua música está sendo ouvida em <span className="text-[#2E2E2E] font-bold">142 países</span>.</p>
          <div className="hidden md:block w-1.5 h-1.5 bg-orange-500 rounded-full"></div>
          <div className="flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-gray-100 shadow-sm w-fit">
            <Globe size={14} className="text-blue-500" />
            <span className="text-[10px] font-black text-[#2E2E2E] uppercase tracking-widest">Sync Live em Luanda</span>
          </div>
        </div>
      </header>

      {/* Grid de Métricas Gigantes */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Streams Globais" 
          value="1.240.500" 
          trend="+12.4%" 
          icon={<PlayCircle size={22} />} 
          onAction={goToAnalytics}
        />
        <StatCard 
          title="Receita Gerada" 
          value="450.000 Kz" 
          trend="+8.2%" 
          icon={<DollarSign size={22} />} 
          onAction={goToAnalytics}
        />
        <StatCard 
          title="Ativos Online" 
          value="14" 
          icon={<ListMusic size={22} />} 
          onAction={() => onNavigate('catalog')}
        />
        <StatCard 
          title="Novos Ouvintes" 
          value="85.4k" 
          trend="+5.1%" 
          icon={<TrendingUp size={22} />} 
          onAction={goToAnalytics}
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 md:gap-12">
        {/* Lançamentos */}
        <div className="xl:col-span-2 space-y-8">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl md:text-3xl font-black text-[#2E2E2E] tracking-tight">Últimos Lançamentos</h2>
            <button 
              onClick={() => onNavigate('catalog')}
              className="text-[10px] font-black text-orange-600 hover:tracking-widest transition-all uppercase tracking-widest border-b-2 border-orange-100 pb-1"
            >
              Ver Catálogo Completo
            </button>
          </div>
          
          <div className="grid grid-cols-1 gap-5">
            {recentReleases.map((rel) => (
              <div 
                key={rel.id} 
                onClick={() => onNavigate('catalog')}
                className="bg-white p-5 md:p-6 rounded-[2.5rem] border border-gray-50 flex items-center justify-between group hover:shadow-2xl hover:shadow-gray-200/50 transition-all duration-500 cursor-pointer"
              >
                <div className="flex items-center gap-4 md:gap-6">
                  <div className="w-16 h-16 md:w-20 md:h-20 bg-gray-100 rounded-[1.5rem] md:rounded-[2rem] flex-shrink-0 overflow-hidden shadow-inner group-hover:scale-105 transition-transform duration-500">
                    <img 
                      src={`https://picsum.photos/seed/${rel.id}/200/200`} 
                      className="w-full h-full object-cover grayscale-[0.2] group-hover:grayscale-0 transition-all" 
                      alt={rel.title} 
                    />
                  </div>
                  <div>
                    <h4 className="text-lg md:text-xl font-black text-[#2E2E2E] leading-tight group-hover:text-orange-600 transition-colors">{rel.title}</h4>
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-1">{rel.artist}</p>
                    <div className="mt-2.5 flex items-center gap-3">
                      <span className={`px-2.5 py-1 rounded-full text-[8px] font-black uppercase tracking-widest ${
                        rel.status === ReleaseStatus.DISTRIBUTED ? 'bg-green-50 text-green-700' :
                        rel.status === ReleaseStatus.APPROVED ? 'bg-blue-50 text-blue-700' :
                        'bg-yellow-50 text-yellow-700'
                      }`}>
                        {rel.status}
                      </span>
                      <span className="text-[10px] font-bold text-gray-200">|</span>
                      <span className="text-[10px] font-bold text-gray-400">{rel.date}</span>
                    </div>
                  </div>
                </div>
                
                <div className="hidden md:flex flex-col items-end gap-1">
                  <span className="text-[9px] font-black text-gray-300 uppercase tracking-widest">Streams</span>
                  <span className="text-2xl font-black text-[#2E2E2E] tracking-tighter">{rel.streams}</span>
                  <button className="mt-1 w-9 h-9 flex items-center justify-center bg-gray-50 text-gray-400 rounded-2xl group-hover:bg-orange-500 group-hover:text-white transition-all">
                    <ArrowUpRight size={18} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Center Sidebar */}
        <div className="space-y-6 flex flex-col">
          <div className="bg-[#2E2E2E] rounded-[3rem] p-10 md:p-12 text-white relative overflow-hidden group flex-1">
            <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/10 rounded-full -mr-32 -mt-32 blur-[100px] group-hover:bg-orange-500/20 transition-all duration-1000"></div>
            <div className="relative z-10 h-full flex flex-col">
              <div className="w-14 h-14 bg-orange-500 rounded-2xl flex items-center justify-center text-white mb-8 shadow-2xl shadow-orange-500/40 group-hover:rotate-12 transition-transform">
                <Upload size={28} />
              </div>
              <h3 className="text-3xl md:text-4xl font-black tracking-tighter leading-tight">Lançar agora.</h3>
              <p className="text-gray-400 text-sm mt-5 font-medium leading-relaxed">
                Nossa curadoria está online. Envie seu material e receba o ISRC em até <span className="text-white font-bold">2 horas</span>.
              </p>
              <button 
                onClick={() => onNavigate('upload')}
                className="w-full mt-auto py-5 bg-white text-[#2E2E2E] rounded-[1.5rem] font-black text-[10px] uppercase tracking-[0.2em] hover:bg-orange-500 hover:text-white transition-all shadow-2xl shadow-black/10 active:scale-95"
              >
                Iniciar Upload
              </button>
            </div>
          </div>

          <div className="bg-white rounded-[2.5rem] p-8 md:p-10 border border-gray-100 shadow-sm">
            <h4 className="text-[10px] font-black text-[#2E2E2E] uppercase tracking-widest mb-5 flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-orange-500 rounded-full animate-pulse"></div> Dica Pro Stream
            </h4>
            <p className="text-gray-500 text-sm leading-relaxed">
              Músicas enviadas com <span className="text-[#2E2E2E] font-bold italic">Canva Video Covers</span> tendem a performar <span className="text-green-500 font-bold">40% melhor</span> no Instagram e TikTok.
            </p>
            <button 
              onClick={goToAnalytics}
              className="mt-6 flex items-center gap-2 text-[10px] font-black text-orange-600 uppercase tracking-widest group"
            >
              Aprender Mais <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
