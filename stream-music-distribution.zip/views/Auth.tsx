
import React, { useState } from 'react';
import { Phone, Lock, ArrowRight, Music, Globe, CheckCircle2, Loader2, ShieldCheck } from 'lucide-react';

interface AuthProps {
  onLogin: (userData: any) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone || !password) {
      setError('Por favor, preencha todos os campos.');
      return;
    }

    setIsLoading(true);
    setError('');

    // Simulação de autenticação
    setTimeout(() => {
      setIsLoading(false);
      // Se o número for o do proprietário (exemplo), dá acesso admin
      const isAdmin = phone === '957729023' || phone === '244957729023';
      
      onLogin({
        name: isAdmin ? "Administrador Master" : "Artista Angolano",
        phone: phone,
        isAdmin: isAdmin,
        avatar: "https://picsum.photos/seed/auth/100/100"
      });
    }, 1500);
  };

  return (
    <div className="min-h-screen w-full bg-[#F8F8F8] flex items-center justify-center p-4 md:p-8 font-inter">
      <div className="max-w-6xl w-full bg-white rounded-[3rem] shadow-2xl shadow-gray-200 overflow-hidden flex flex-col lg:flex-row min-h-[700px] animate-premium">
        
        {/* Lado Esquerdo - Branding & Info */}
        <div className="lg:w-1/2 bg-[#2E2E2E] p-12 md:p-20 text-white relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/10 rounded-full -mr-48 -mt-48 blur-[100px]"></div>
          
          <div className="relative z-10">
            <div className="flex flex-col mb-16">
              <span className="text-xl font-black tracking-[0.2em]">STREAM MUSIC</span>
              <span className="text-sm font-bold text-orange-500 tracking-[0.4em]">DISTRIBUTION</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-black tracking-tighter leading-tight mb-8">
              Sua música de <span className="text-orange-500 underline decoration-4 underline-offset-8">Angola</span> para o mundo.
            </h1>
            
            <div className="space-y-6">
              {[
                "Distribuição em +150 plataformas globais.",
                "Receba royalties via conta bancária angolana (BAI, BFA, etc).",
                "Gestão simplificada de ISRC e UPC."
              ].map((text, i) => (
                <div key={i} className="flex items-center gap-4 group">
                  <div className="w-10 h-10 bg-white/5 rounded-2xl flex items-center justify-center group-hover:bg-orange-500 transition-colors">
                    <CheckCircle2 size={18} className="text-orange-500 group-hover:text-white" />
                  </div>
                  <p className="text-sm font-medium text-gray-300 group-hover:text-white transition-colors">{text}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="relative z-10 pt-12 border-t border-white/5 flex items-center gap-6">
            <div className="flex -space-x-4">
              {[1,2,3].map(i => (
                <img key={i} src={`https://picsum.photos/seed/${i+10}/50/50`} className="w-10 h-10 rounded-full border-2 border-[#2E2E2E]" alt="Artist" />
              ))}
            </div>
            <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">
              Junte-se a <span className="text-white">+2.500 artistas</span> angolanos.
            </p>
          </div>
        </div>

        {/* Lado Direito - Formulário */}
        <div className="flex-1 p-12 md:p-20 flex flex-col justify-center bg-white relative">
          <div className="max-w-md mx-auto w-full">
            <header className="mb-12">
              <h2 className="text-3xl font-black text-[#2E2E2E] tracking-tighter mb-2">
                {isLogin ? 'Bem-vindo de volta' : 'Criar sua conta'}
              </h2>
              <p className="text-sm font-medium text-gray-400">
                {isLogin 
                  ? 'Acesse sua conta para gerenciar seus lançamentos.' 
                  : 'Comece a distribuir sua música globalmente hoje mesmo.'}
              </p>
            </header>

            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <div className="p-4 bg-red-50 text-red-600 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-red-100 flex items-center gap-3 animate-premium">
                  <Globe size={16} /> {error}
                </div>
              )}

              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-4">Número de Telefone (Angola)</label>
                <div className="relative group">
                  <div className="absolute left-6 top-1/2 -translate-y-1/2 flex items-center gap-2 pr-3 border-r border-gray-100 text-[#2E2E2E] font-black text-sm">
                    <Phone size={16} className="text-orange-500" />
                    <span>+244</span>
                  </div>
                  <input 
                    type="tel" 
                    placeholder="9XX XXX XXX" 
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pl-28 pr-8 py-5 bg-gray-50 rounded-[1.5rem] border-transparent outline-none font-bold text-sm shadow-inner focus:bg-white focus:border-orange-100 transition-all"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center ml-4">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Senha de Acesso</label>
                  {isLogin && <button type="button" className="text-[9px] font-black text-orange-500 uppercase tracking-widest hover:underline">Esqueceu?</button>}
                </div>
                <div className="relative">
                  <Lock className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                  <input 
                    type="password" 
                    placeholder="••••••••" 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-16 pr-8 py-5 bg-gray-50 rounded-[1.5rem] border-transparent outline-none font-bold text-sm shadow-inner focus:bg-white focus:border-orange-100 transition-all"
                  />
                </div>
              </div>

              <button 
                type="submit"
                disabled={isLoading}
                className="w-full py-6 bg-[#2E2E2E] text-white rounded-[1.5rem] font-black text-[10px] uppercase tracking-[0.2em] shadow-xl shadow-black/10 hover:bg-black transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50"
              >
                {isLoading ? (
                  <Loader2 size={18} className="animate-spin" />
                ) : (
                  <>
                    {isLogin ? 'Entrar na Plataforma' : 'Criar minha conta'}
                    <ArrowRight size={18} />
                  </>
                )}
              </button>
            </form>

            {/* Fix: Changed </div> to </footer> to match opening <footer /> tag */}
            <footer className="mt-12 pt-8 border-t border-gray-50 text-center">
              <p className="text-xs font-medium text-gray-400">
                {isLogin ? 'Não tem uma conta?' : 'Já possui uma conta?'}
                <button 
                  onClick={() => setIsLogin(!isLogin)}
                  className="ml-2 font-black text-orange-500 uppercase tracking-widest hover:underline transition-all"
                >
                  {isLogin ? 'Cadastrar-se' : 'Fazer Login'}
                </button>
              </p>
            </footer>
            
            {/* Disclaimer para Admin */}
            <div className="mt-8 p-6 bg-orange-50/50 rounded-2xl border border-orange-100/50 flex items-start gap-4">
              <ShieldCheck className="text-orange-500 flex-shrink-0" size={20} />
              <p className="text-[10px] font-bold text-gray-500 leading-relaxed uppercase tracking-tight">
                Nota: O acesso administrativo é restrito ao proprietário da plataforma. Para suporte, contacte o TI.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Auth;
