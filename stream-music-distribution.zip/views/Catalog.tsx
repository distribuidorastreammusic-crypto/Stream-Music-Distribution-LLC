
import React, { useState, useMemo } from 'react';
import { Search, Filter, MoreVertical, Disc, CheckCircle2, Clock, AlertCircle, X, Music, Globe, BarChart3, Calendar } from 'lucide-react';
import { ReleaseStatus } from '../types';

interface CatalogProps {
  onNavigate?: (view: string) => void;
  releases: any[];
  onRemoveRelease: (id: string) => void;
}

const Catalog: React.FC<CatalogProps> = ({ onNavigate, releases, onRemoveRelease }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRelease, setSelectedRelease] = useState<any>(null);

  const filteredReleases = useMemo(() => {
    return releases.filter(r => 
      r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.type.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery, releases]);

  const approved = filteredReleases.filter(r => r.status === ReleaseStatus.DISTRIBUTED || r.status === ReleaseStatus.APPROVED);
  const pending = filteredReleases.filter(r => r.status === ReleaseStatus.PENDING);
  const rejected = filteredReleases.filter(r => r.status === ReleaseStatus.REJECTED);

  const handleEdit = () => {
    if (!selectedRelease) return;
    onNavigate?.('upload');
    setSelectedRelease(null);
  };

  const handleWithdraw = () => {
    if (!selectedRelease) return;
    const confirmed = window.confirm(`Tem certeza que deseja retirar "${selectedRelease.title}"?`);
    if (confirmed) {
      onRemoveRelease(selectedRelease.id);
      setSelectedRelease(null);
    }
  };

  const ReleaseGrid = ({ title, items, icon: Icon, colorClass }: { title: string, items: any[], icon: any, colorClass: string }) => {
    if (items.length === 0) return null;
    
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3 border-b border-gray-100 pb-4">
          <Icon size={20} className={colorClass} />
          <h2 className="text-sm font-black text-[#2E2E2E] uppercase tracking-[0.2em]">{title}</h2>
          <span className="bg-gray-100 text-gray-500 text-[10px] font-bold px-2 py-0.5 rounded-full">{items.length}</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-4">
          {items.map(rel => (
            <div key={rel.id} className="group cursor-pointer">
              <div className="aspect-square relative rounded-2xl overflow-hidden shadow-sm border border-gray-50 bg-white group-hover:shadow-xl group-hover:-translate-y-1 transition-all duration-500">
                <img 
                  src={rel.coverUrl || `https://picsum.photos/seed/${rel.id}/300/300`} 
                  alt={rel.title} 
                  className="w-full h-full object-cover grayscale-[0.1] group-hover:grayscale-0 transition-all duration-700" 
                />
                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                  <button onClick={(e) => { e.stopPropagation(); setSelectedRelease(rel); }} className="p-1.5 bg-white/90 backdrop-blur-md rounded-lg text-gray-900 shadow-lg hover:bg-orange-500 hover:text-white transition-all">
                    <MoreVertical size={14} />
                  </button>
                </div>
                <div className={`absolute bottom-2 left-2 px-2 py-0.5 rounded-lg text-[8px] font-black uppercase tracking-tighter text-white shadow-lg ${
                  rel.status === ReleaseStatus.DISTRIBUTED || rel.status === ReleaseStatus.APPROVED ? 'bg-green-500' :
                  rel.status === ReleaseStatus.PENDING ? 'bg-yellow-500' : 'bg-red-500'
                }`}>
                  {rel.status === ReleaseStatus.DISTRIBUTED ? 'No Ar' : rel.status}
                </div>
              </div>
              <div className="mt-3 px-1" onClick={() => setSelectedRelease(rel)}>
                <h3 className="text-[11px] font-black text-[#2E2E2E] truncate leading-tight group-hover:text-orange-600 transition-colors">{rel.title}</h3>
                <p className="text-[9px] font-bold text-gray-400 uppercase tracking-tighter mt-0.5">{rel.type} • {rel.tracks} fxs</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-12 animate-premium relative">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-5xl font-black text-[#2E2E2E] tracking-tighter">Meu Catálogo</h1>
          <p className="text-gray-400 mt-2 text-xs font-bold uppercase tracking-widest">Gestão de Fonogramas e Obras Digitais</p>
        </div>
        <div className="flex items-center gap-3">
           <div className="relative group">
             <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
             <input type="text" placeholder="Filtrar lançamentos..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-11 pr-4 py-2.5 bg-white border border-transparent rounded-xl outline-none focus:ring-4 focus:ring-orange-500/5 text-xs font-bold w-64 shadow-sm" />
           </div>
           <button className="p-2.5 bg-white border border-gray-100 rounded-xl text-gray-400 hover:text-[#2E2E2E] shadow-sm"><Filter size={18} /></button>
        </div>
      </header>

      <div className="space-y-16">
        {filteredReleases.length > 0 ? (
          <>
            <ReleaseGrid title="Aprovados & Distribuídos" items={approved} icon={CheckCircle2} colorClass="text-green-500" />
            <ReleaseGrid title="Em Análise pela Curadoria" items={pending} icon={Clock} colorClass="text-yellow-500" />
            <ReleaseGrid title="Não Aprovados (Rejeitados)" items={rejected} icon={AlertCircle} colorClass="text-red-500" />
          </>
        ) : (
          <div className="py-40 text-center bg-white rounded-[3rem] border border-dashed border-gray-200">
            <Disc size={48} className="mx-auto text-gray-200 mb-6" />
            <h3 className="text-xl font-black text-gray-400 uppercase tracking-widest">Catálogo Vazio</h3>
          </div>
        )}
      </div>

      {selectedRelease && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 md:p-12">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-md" onClick={() => setSelectedRelease(null)} />
          <div className="relative bg-white w-full max-w-4xl rounded-[3.5rem] overflow-hidden shadow-2xl animate-premium flex flex-col md:flex-row max-h-[90vh]">
            <div className="w-full md:w-2/5 bg-gray-100 relative overflow-hidden h-64 md:h-auto">
              <img src={selectedRelease.coverUrl || `https://picsum.photos/seed/${selectedRelease.id}/800/800`} alt={selectedRelease.title} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 p-8 md:p-14 overflow-y-auto custom-scrollbar bg-white">
              <div className="flex items-center justify-between mb-10">
                <h2 className="text-4xl font-black text-[#2E2E2E] tracking-tighter leading-tight">{selectedRelease.title}</h2>
                <button onClick={() => setSelectedRelease(null)} className="w-12 h-12 flex items-center justify-center bg-gray-50 text-gray-400 rounded-2xl hover:text-red-500"><X size={24} /></button>
              </div>
              <div className="grid grid-cols-2 gap-8 text-sm">
                <div><span className="text-[9px] font-black text-gray-400 uppercase">Gênero</span><p className="font-bold">{selectedRelease.genre}</p></div>
                <div><span className="text-[9px] font-black text-gray-400 uppercase">Data</span><p className="font-bold">{selectedRelease.date}</p></div>
                <div><span className="text-[9px] font-black text-gray-400 uppercase">UPC</span><p className="font-mono">{selectedRelease.upc}</p></div>
                <div><span className="text-[9px] font-black text-gray-400 uppercase">ISRC</span><p className="font-mono">{selectedRelease.isrc}</p></div>
              </div>
              <div className="mt-10 flex gap-4">
                <button onClick={handleEdit} className="flex-1 py-5 bg-[#2E2E2E] text-white rounded-2xl font-black text-[10px] uppercase">Editar Metadados</button>
                <button onClick={handleWithdraw} className="px-8 py-5 bg-gray-50 text-gray-400 rounded-2xl font-black text-[10px] uppercase hover:text-red-500">Retirar</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Catalog;
