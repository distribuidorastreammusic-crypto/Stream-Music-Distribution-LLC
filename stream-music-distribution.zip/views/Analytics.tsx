
import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Download, Globe, PlayCircle, Calendar, Filter } from 'lucide-react';
import StatCard from '../components/StatCard';

const data = [
  { name: 'Jan', streams: 4000 },
  { name: 'Fev', streams: 3000 },
  { name: 'Mar', streams: 2000 },
  { name: 'Abr', streams: 2780 },
  { name: 'Mai', streams: 1890 },
  { name: 'Jun', streams: 2390 },
  { name: 'Jul', streams: 3490 },
];

const platformData = [
  { name: 'Spotify', value: 400 },
  { name: 'Boomplay', value: 300 },
  { name: 'Apple Music', value: 300 },
  { name: 'YouTube', value: 200 },
];

const COLORS = ['#F97316', '#2E2E2E', '#22C55E', '#3B82F6'];

const Analytics: React.FC = () => {
  const [period, setPeriod] = useState('30D');
  const [isExporting, setIsExporting] = useState(false);

  const handleExport = () => {
    setIsExporting(true);
    // Simulando um processo de exportação
    setTimeout(() => {
      alert("Relatório consolidado exportado com sucesso em formato CSV.");
      setIsExporting(false);
    }, 1500);
  };

  const handleDetailClick = (metric: string) => {
    alert(`Abrindo relatório detalhado para: ${metric}`);
  };

  const periods = [
    { id: '7D', label: '7 Dias' },
    { id: '30D', label: '30 Dias' },
    { id: '12M', label: '12 Meses' },
    { id: 'ALL', label: 'Tudo' }
  ];

  return (
    <div className="space-y-12 animate-premium">
      <header className="flex flex-col xl:flex-row xl:items-center justify-between gap-8">
        <div>
          <h1 className="text-5xl font-black text-[#2E2E2E] tracking-tighter">Performance Global</h1>
          <p className="text-gray-400 mt-2 text-xs font-bold uppercase tracking-widest">Análise de Audiência e Royalties em Tempo Real</p>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          {/* Seletor de Período Premium */}
          <div className="bg-white p-1.5 rounded-[1.25rem] border border-gray-100 shadow-sm flex gap-1">
            {periods.map((p) => (
              <button
                key={p.id}
                onClick={() => setPeriod(p.id)}
                className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                  period === p.id 
                    ? 'bg-[#2E2E2E] text-white shadow-lg' 
                    : 'text-gray-400 hover:text-[#2E2E2E] hover:bg-gray-50'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          <button 
            onClick={handleExport}
            disabled={isExporting}
            className={`flex items-center gap-3 px-8 py-4 bg-white border border-gray-100 rounded-[1.25rem] text-[10px] font-black uppercase tracking-widest transition-all shadow-sm hover:shadow-md active:scale-95 ${
              isExporting ? 'opacity-50 cursor-not-allowed' : 'text-[#2E2E2E] hover:border-orange-500 hover:text-orange-600'
            }`}
          >
            {isExporting ? (
              <div className="w-4 h-4 border-2 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <Download size={16} />
            )}
            {isExporting ? 'Exportando...' : 'Exportar CSV'}
          </button>
        </div>
      </header>

      {/* Grid de Métricas com Botões Funcionais */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Total Streams" 
          value="1,245,678" 
          icon={<PlayCircle size={22} />} 
          trend="+15%" 
          onAction={() => handleDetailClick('Total Streams')}
        />
        <StatCard 
          title="Downloads" 
          value="12,403" 
          icon={<Download size={22} />} 
          trend="+2%" 
          onAction={() => handleDetailClick('Downloads')}
        />
        <StatCard 
          title="Alcance Global" 
          value="142 Países" 
          icon={<Globe size={22} />} 
          onAction={() => handleDetailClick('Alcance Global')}
        />
        <StatCard 
          title="Retenção Fans" 
          value="2.4%" 
          icon={<TrendingUp size={22} />} 
          trend="-0.5%" 
          onAction={() => handleDetailClick('Retenção Fans')}
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-10">
        {/* Gráfico de Barras Premium */}
        <div className="bg-white p-10 rounded-[3.5rem] border border-gray-100 shadow-sm group hover:shadow-2xl hover:shadow-gray-200/50 transition-all duration-700">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h3 className="text-xl font-black text-[#2E2E2E] uppercase tracking-tighter">Crescimento de Audiência</h3>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-1">Evolução mensal de reproduções</p>
            </div>
            <div className="p-3 bg-gray-50 rounded-2xl text-gray-400 group-hover:bg-orange-50 group-hover:text-orange-500 transition-colors">
              <Calendar size={20} />
            </div>
          </div>
          
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F3F4F6" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fill: '#9CA3AF', fontSize: 10, fontWeight: 700}} 
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fill: '#9CA3AF', fontSize: 10, fontWeight: 700}} 
                />
                <Tooltip 
                  cursor={{fill: '#F9731608'}} 
                  contentStyle={{
                    borderRadius: '24px', 
                    border: 'none', 
                    boxShadow: '0 25px 50px -12px rgb(0 0 0 / 0.15)',
                    padding: '20px'
                  }} 
                />
                <Bar 
                  dataKey="streams" 
                  fill="#F97316" 
                  radius={[12, 12, 12, 12]} 
                  barSize={32}
                  className="hover:fill-[#2E2E2E] transition-colors"
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Gráfico de Pizza Premium */}
        <div className="bg-white p-10 rounded-[3.5rem] border border-gray-100 shadow-sm group hover:shadow-2xl hover:shadow-gray-200/50 transition-all duration-700">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h3 className="text-xl font-black text-[#2E2E2E] uppercase tracking-tighter">Share por Plataforma</h3>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-1">Distribuição de plays nas lojas</p>
            </div>
            <div className="p-3 bg-gray-50 rounded-2xl text-gray-400 group-hover:bg-blue-50 group-hover:text-blue-500 transition-colors">
              <Filter size={20} />
            </div>
          </div>

          <div className="h-80 w-full flex flex-col md:flex-row items-center gap-10">
            <div className="flex-1 w-full h-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={platformData}
                    cx="50%"
                    cy="50%"
                    innerRadius={70}
                    outerRadius={110}
                    paddingAngle={8}
                    dataKey="value"
                    stroke="none"
                  >
                    {platformData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} className="hover:opacity-80 transition-opacity cursor-pointer" />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{
                      borderRadius: '20px', 
                      border: 'none', 
                      boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-1 gap-4 w-full md:w-auto">
              {platformData.map((p, i) => (
                <div key={p.name} className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl border border-transparent hover:border-gray-100 transition-all group/item">
                  <div className="w-4 h-4 rounded-full shadow-sm" style={{backgroundColor: COLORS[i]}}></div>
                  <div className="flex flex-col">
                    <span className="text-[10px] font-black text-[#2E2E2E] uppercase tracking-tighter">{p.name}</span>
                    <span className="text-[9px] font-bold text-gray-400 uppercase">{Math.round((p.value/1200)*100)}% do tráfego</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
