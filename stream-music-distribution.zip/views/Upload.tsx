
import React, { useState, useRef } from 'react';
import { 
  Plus, 
  Trash2, 
  Check, 
  Upload as UploadIcon, 
  Music, 
  ArrowRight, 
  ArrowLeft, 
  Image as ImageIcon,
  FileText,
  CreditCard,
  PenTool,
  AlertCircle,
  Globe,
  CheckCircle2,
  Disc,
  Info
} from 'lucide-react';
import { GENRES, SUB_GENRES, PLATFORMS } from '../constants';
import { ReleaseStatus } from '../types';

interface UploadProps {
  onAddRelease: (release: any) => void;
  onNavigate: (view: string) => void;
}

const Upload: React.FC<UploadProps> = ({ onAddRelease, onNavigate }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    // Página 1
    title: '',
    version: '',
    mainArtists: [''],
    featuringArtists: [] as string[],
    composers: [''],
    producers: [''],
    genre: GENRES[0],
    subGenre: SUB_GENRES[0],
    language: 'Português',
    country: 'Angola',
    releaseDate: new Date().toISOString().split('T')[0],
    label: '',
    isrc: '',
    upc: '',
    isExplicit: 'Não',
    
    // Página 2
    releaseType: 'Single',
    trackCount: '1',
    lyrics: '',
    contentId: false,
    selectedPlatforms: ['Spotify', 'Apple Music', 'Audiomack', 'Boomplay'],
    
    // Página 3
    selectedPlan: 'single',

    // Página 4
    termsAccepted: false,
    signature: ''
  });

  const [coverUrl, setCoverUrl] = useState<string>('');
  const [audioName, setAudioName] = useState<string>('');
  const [proofName, setProofName] = useState<string>('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);
  const proofInputRef = useRef<HTMLInputElement>(null);

  const updateArrayField = (field: 'mainArtists' | 'featuringArtists' | 'composers' | 'producers', index: number, value: string) => {
    const newArr = [...formData[field]];
    newArr[index] = value;
    setFormData({ ...formData, [field]: newArr });
  };

  const addField = (field: 'mainArtists' | 'featuringArtists' | 'composers' | 'producers') => {
    setFormData({ ...formData, [field]: [...formData[field], ''] });
  };

  const removeField = (field: 'mainArtists' | 'featuringArtists' | 'composers' | 'producers', index: number) => {
    if (formData[field].length <= 1 && (field === 'mainArtists' || field === 'composers' || field === 'producers')) return;
    const newArr = formData[field].filter((_, i) => i !== index);
    setFormData({ ...formData, [field]: newArr });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'cover' | 'audio' | 'proof') => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (type === 'cover') {
      const url = URL.createObjectURL(file);
      setCoverUrl(url);
    }
    if (type === 'audio') setAudioName(file.name);
    if (type === 'proof') setProofName(file.name);
  };

  const togglePlatform = (plat: string) => {
    const current = formData.selectedPlatforms;
    if (current.includes(plat)) {
      setFormData({ ...formData, selectedPlatforms: current.filter(p => p !== plat) });
    } else {
      setFormData({ ...formData, selectedPlatforms: [...current, plat] });
    }
  };

  const handleFinalSubmit = () => {
    if (!formData.title) return alert("Por favor, insira o título da música.");
    if (!coverUrl) return alert("A capa da obra é obrigatória.");
    if (!audioName) return alert("O ficheiro de áudio é obrigatório.");
    if (!proofName) return alert("É necessário anexar o comprovativo de pagamento BAI.");
    if (!formData.termsAccepted) return alert("É necessário aceitar os termos de distribuição.");
    if (!formData.signature) return alert("Por favor, assine o documento digitando seu nome.");

    const newRelease = {
      id: Math.random().toString(36).substr(2, 9),
      title: formData.title,
      type: formData.releaseType,
      status: ReleaseStatus.PENDING,
      date: formData.releaseDate,
      tracks: parseInt(formData.trackCount),
      genre: formData.genre,
      upc: formData.upc || '8597' + Math.floor(Math.random() * 100000000),
      isrc: formData.isrc || 'AO-SMC-26-' + Math.floor(Math.random() * 100000),
      coverUrl: coverUrl,
      lyrics: formData.lyrics
    };

    onAddRelease(newRelease);
  };

  const nextStep = () => setStep(s => Math.min(s + 1, 4));
  const prevStep = () => setStep(s => Math.max(s - 1, 1));

  const renderFieldGroup = (field: 'mainArtists' | 'featuringArtists' | 'composers' | 'producers', label: string) => (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">{label}</label>
        <button onClick={() => addField(field)} className="p-1.5 bg-gray-50 text-[#2E2E2E] rounded-lg hover:bg-orange-500 hover:text-white transition-all shadow-sm">
          <Plus size={12} />
        </button>
      </div>
      {formData[field].map((val: string, idx: number) => (
        <div key={idx} className="flex gap-3 animate-premium">
          <input 
            type="text" 
            placeholder={`Nome do ${label}`}
            value={val} 
            onChange={e => updateArrayField(field, idx, e.target.value)} 
            className="flex-1 px-5 py-3.5 bg-gray-50 rounded-xl border-transparent outline-none font-bold text-xs shadow-inner focus:bg-white focus:border-gray-100 transition-all" 
          />
          {formData[field].length > (field === 'featuringArtists' ? 0 : 1) && (
            <button onClick={() => removeField(field, idx)} className="p-3 text-red-500 hover:bg-red-50 rounded-xl transition-colors">
              <Trash2 size={14} />
            </button>
          )}
        </div>
      ))}
    </div>
  );

  return (
    <div className="max-w-[1300px] mx-auto pb-16 animate-premium">
      {/* Progresso Stepper */}
      <header className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-8">
        <div>
          <span className="text-[10px] font-black text-orange-500 uppercase tracking-[0.4em] mb-2.5 block">Portal de Distribuição Angola</span>
          <h1 className="text-4xl md:text-5xl font-black text-[#2E2E2E] tracking-tighter">Novo Lançamento</h1>
        </div>
        <div className="flex gap-4">
          {[1, 2, 3, 4].map((s) => (
            <div key={s} className="flex flex-col items-center gap-2">
              <div className={`w-12 md:w-20 h-2 rounded-full transition-all duration-700 ${step >= s ? 'bg-orange-500 shadow-lg shadow-orange-500/20' : 'bg-gray-200'}`} />
              <span className={`text-[8px] font-black uppercase tracking-widest ${step === s ? 'text-[#2E2E2E]' : 'text-gray-300'}`}>Etapa 0{s}</span>
            </div>
          ))}
        </div>
      </header>

      <div className="bg-white rounded-[4rem] border border-gray-100 shadow-2xl shadow-gray-200/40 overflow-hidden min-h-[750px] flex flex-col lg:flex-row">
        
        {/* Lado Esquerdo - Info da Etapa */}
        <div className="w-full lg:w-[320px] bg-gray-50/50 p-12 border-r border-gray-100 flex flex-col gap-12">
          {[
            { id: 1, label: 'Identidade', desc: 'Dados e Metadados' },
            { id: 2, label: 'Ativos', desc: 'Mídia e Plataformas' },
            { id: 3, label: 'Investimento', desc: 'Escolha seu Plano' },
            { id: 4, label: 'Checkout', desc: 'Conclusão Final' }
          ].map((s) => (
            <div key={s.id} className="flex gap-5 items-start">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-xs transition-all duration-500 ${
                step === s.id ? 'bg-[#2E2E2E] text-white scale-110 shadow-xl shadow-black/10' : 
                step > s.id ? 'bg-orange-500 text-white' : 'bg-white text-gray-300 border border-gray-100'
              }`}>
                {step > s.id ? <Check size={18} strokeWidth={3} /> : s.id}
              </div>
              <div className="flex flex-col pt-1">
                <span className={`text-[10px] font-black tracking-tight uppercase ${step >= s.id ? 'text-[#2E2E2E]' : 'text-gray-300'}`}>{s.label}</span>
                <span className="text-[8px] font-bold text-gray-400 uppercase tracking-widest mt-0.5">{s.desc}</span>
              </div>
            </div>
          ))}
          
          <div className="mt-auto p-8 bg-[#2E2E2E] rounded-[2.5rem] text-white relative overflow-hidden">
            <Info size={20} className="text-orange-500 mb-4" />
            <p className="text-[10px] font-bold leading-relaxed text-gray-400 relative z-10">
              Verifique todos os campos. Erros nos metadados podem causar rejeição pelas lojas.
            </p>
            <div className="absolute -bottom-8 -right-8 w-24 h-24 bg-orange-500/10 rounded-full blur-2xl"></div>
          </div>
        </div>

        {/* Lado Direito - Campos */}
        <div className="flex-1 p-8 md:p-16 overflow-y-auto custom-scrollbar">
          
          {step === 1 && (
            <div className="space-y-10 animate-premium">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Título da Música</label>
                  <input type="text" placeholder="Ex: Luanda em Festa" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} className="w-full px-6 py-4 bg-gray-50 rounded-2xl border-transparent focus:bg-white focus:border-gray-200 outline-none font-bold text-sm transition-all shadow-inner" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Versão (Opcional)</label>
                  <input type="text" placeholder="Ex: Acoustic Mix" value={formData.version} onChange={e => setFormData({...formData, version: e.target.value})} className="w-full px-6 py-4 bg-gray-50 rounded-2xl border-transparent focus:bg-white focus:border-gray-200 outline-none font-bold text-sm transition-all shadow-inner" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {renderFieldGroup('mainArtists', 'Artista Principal')}
                {renderFieldGroup('featuringArtists', 'Artista Participante')}
                {renderFieldGroup('composers', 'Compositor')}
                {renderFieldGroup('producers', 'Produtor')}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Gênero Musical</label>
                  <select value={formData.genre} onChange={e => setFormData({...formData, genre: e.target.value})} className="w-full px-5 py-4 bg-gray-50 rounded-xl border-transparent outline-none font-bold text-xs shadow-inner cursor-pointer">
                    {GENRES.map(g => <option key={g} value={g}>{g}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Subgênero</label>
                  <select value={formData.subGenre} onChange={e => setFormData({...formData, subGenre: e.target.value})} className="w-full px-5 py-4 bg-gray-50 rounded-xl border-transparent outline-none font-bold text-xs shadow-inner cursor-pointer">
                    {SUB_GENRES.map(sg => <option key={sg} value={sg}>{sg}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Idioma</label>
                  <select value={formData.language} onChange={e => setFormData({...formData, language: e.target.value})} className="w-full px-5 py-4 bg-gray-50 rounded-xl border-transparent outline-none font-bold text-xs shadow-inner cursor-pointer">
                    <option>Português</option>
                    <option>Inglês</option>
                    <option>Francês</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">País de Origem</label>
                  <input type="text" value={formData.country} onChange={e => setFormData({...formData, country: e.target.value})} className="w-full px-6 py-4 bg-gray-50 rounded-xl border-transparent focus:bg-white focus:border-gray-200 outline-none font-bold text-sm shadow-inner" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Data de Lançamento</label>
                  <input type="date" value={formData.releaseDate} onChange={e => setFormData({...formData, releaseDate: e.target.value})} className="w-full px-5 py-4 bg-gray-50 rounded-xl border-transparent outline-none font-bold text-xs shadow-inner" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Label</label>
                  <input type="text" placeholder="Sua Produtora" value={formData.label} onChange={e => setFormData({...formData, label: e.target.value})} className="w-full px-6 py-4 bg-gray-50 rounded-xl border-transparent focus:bg-white focus:border-gray-200 outline-none font-bold text-sm shadow-inner" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">ISRC (Opcional)</label>
                  <input type="text" placeholder="AO-XXX-26-XXXXX" value={formData.isrc} onChange={e => setFormData({...formData, isrc: e.target.value})} className="w-full px-6 py-4 bg-gray-50 rounded-xl border-transparent focus:bg-white focus:border-gray-200 outline-none font-mono font-bold text-sm shadow-inner" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">UPC (Opcional)</label>
                  <input type="text" placeholder="8597XXXXXXXX" value={formData.upc} onChange={e => setFormData({...formData, upc: e.target.value})} className="w-full px-6 py-4 bg-gray-50 rounded-xl border-transparent focus:bg-white focus:border-gray-200 outline-none font-mono font-bold text-sm shadow-inner" />
                </div>
              </div>

              <div className="p-8 bg-gray-50/50 rounded-[2.5rem] border border-gray-100 flex flex-col md:flex-row items-center justify-between gap-6">
                <div>
                  <span className="text-[9px] font-black text-gray-400 uppercase tracking-[0.2em]">Direitos Autorais (Copyright)</span>
                  <p className="text-sm font-black text-[#2E2E2E] mt-1 select-none">℗ e © 2026 Stream Music Distribution</p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Conteúdo Explícito:</span>
                  <div className="flex bg-white p-1.5 rounded-2xl shadow-sm border border-gray-100">
                    {['Não', 'Sim'].map(opt => (
                      <button key={opt} onClick={() => setFormData({...formData, isExplicit: opt})} className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${formData.isExplicit === opt ? 'bg-[#2E2E2E] text-white shadow-lg shadow-black/10' : 'text-gray-400 hover:text-black'}`}>{opt}</button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-12 animate-premium">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div className="space-y-4">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Tipo de Lançamento</label>
                  <div className="flex gap-2">
                    {['Single', 'EP', 'Álbum'].map(t => (
                      <button key={t} onClick={() => setFormData({...formData, releaseType: t})} className={`flex-1 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest border transition-all ${formData.releaseType === t ? 'bg-[#2E2E2E] text-white border-black shadow-xl shadow-black/5' : 'bg-white text-gray-400 border-gray-100 hover:border-gray-300'}`}>{t}</button>
                    ))}
                  </div>
                </div>
                <div className="space-y-4">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Número de Faixas</label>
                  <input type="number" min="1" value={formData.trackCount} onChange={e => setFormData({...formData, trackCount: e.target.value})} className="w-full px-6 py-4 bg-gray-50 rounded-2xl border-transparent outline-none font-bold text-sm shadow-inner" />
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Letra da Música (Opcional)</label>
                <textarea 
                  rows={6} 
                  placeholder="Introduza a letra para ser distribuída em sincronia..." 
                  value={formData.lyrics} 
                  onChange={e => setFormData({...formData, lyrics: e.target.value})} 
                  className="w-full px-8 py-6 bg-gray-50 rounded-[2.5rem] border-transparent outline-none font-bold text-xs resize-none shadow-inner focus:bg-white focus:border-gray-100 transition-all custom-scrollbar" 
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div className="space-y-4">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] text-center block">Capa (Mín. 3000x3000px)</label>
                  <input type="file" ref={fileInputRef} onChange={e => handleFileUpload(e, 'cover')} accept="image/*" className="hidden" />
                  <div onClick={() => fileInputRef.current?.click()} className={`aspect-square rounded-[3.5rem] border-2 border-dashed flex flex-col items-center justify-center cursor-pointer transition-all hover:scale-[1.01] ${coverUrl ? 'border-green-500 bg-green-50/10' : 'border-gray-200 bg-gray-50 hover:border-orange-500 shadow-inner'}`}>
                    {coverUrl ? <img src={coverUrl} className="w-full h-full object-cover rounded-[3.3rem] shadow-2xl" /> : <><ImageIcon size={40} className="text-gray-300 mb-4" /><span className="text-[10px] font-black uppercase tracking-widest text-gray-400">Anexar Capa</span></>}
                  </div>
                </div>
                <div className="space-y-4">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] text-center block">Áudio (Wav / Flac)</label>
                  <input type="file" ref={audioInputRef} onChange={e => handleFileUpload(e, 'audio')} accept=".wav,.flac" className="hidden" />
                  <div onClick={() => audioInputRef.current?.click()} className={`aspect-square rounded-[3.5rem] border-2 border-dashed flex flex-col items-center justify-center cursor-pointer transition-all hover:scale-[1.01] ${audioName ? 'border-blue-500 bg-blue-50/10' : 'border-gray-200 bg-gray-50 hover:border-orange-500 shadow-inner'}`}>
                    <Music size={40} className={audioName ? 'text-blue-500 mb-4' : 'text-gray-300 mb-4'} />
                    <span className="text-[10px] font-black uppercase max-w-[200px] truncate tracking-widest text-gray-400">{audioName || 'Anexar Áudio'}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between p-8 bg-gray-50/50 rounded-[2.5rem] border border-gray-100 shadow-sm">
                 <div className="flex items-center gap-5">
                   <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-orange-500 shadow-sm"><Globe size={24} /></div>
                   <div>
                     <h4 className="text-xs font-black text-[#2E2E2E] uppercase tracking-widest">Content ID</h4>
                     <p className="text-[9px] font-bold text-gray-400 uppercase tracking-tight mt-0.5">Proteção e monetização no YouTube</p>
                   </div>
                 </div>
                 <button 
                  onClick={() => setFormData({...formData, contentId: !formData.contentId})}
                  className={`w-16 h-9 rounded-full transition-all relative ${formData.contentId ? 'bg-orange-500 shadow-lg shadow-orange-500/30' : 'bg-gray-300'}`}
                 >
                   <div className={`absolute top-1.5 w-6 h-6 bg-white rounded-full transition-all shadow-md ${formData.contentId ? 'left-8' : 'left-1.5'}`} />
                 </button>
              </div>

              <div className="space-y-8">
                 <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Plataformas de Distribuição</h4>
                 <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
                   {PLATFORMS.slice(0, 18).map(plat => (
                     <button key={plat} onClick={() => togglePlatform(plat)} className={`px-4 py-3.5 rounded-2xl border text-[9px] font-black uppercase tracking-tighter transition-all ${formData.selectedPlatforms.includes(plat) ? 'bg-[#2E2E2E] text-white border-[#2E2E2E] shadow-xl shadow-black/5' : 'bg-white text-gray-400 border-gray-100 hover:border-gray-200'}`}>{plat}</button>
                   ))}
                 </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-12 animate-premium flex flex-col items-center justify-center min-h-[500px]">
              <div className="text-center mb-10">
                <h2 className="text-3xl font-black text-[#2E2E2E] uppercase tracking-tighter">Escolha o seu Plano</h2>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-[0.3em] mt-3">Transparência total sem taxas ocultas</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-5xl">
                {[
                  { id: 'single', label: 'Single', price: '2.500 Kz', desc: '1 Faixa Digital', icon: Music },
                  { id: 'album', label: 'Álbum / EP', price: '13.000 Kz', desc: 'Até 25 Faixas', icon: Disc },
                  { id: 'unlimited', label: 'Ilimitado', price: '30.000 Kz', desc: '1 Ano Ilimitado', icon: Globe }
                ].map(plan => (
                  <div key={plan.id} onClick={() => setFormData({...formData, selectedPlan: plan.id})} className={`p-12 rounded-[3.5rem] border-2 cursor-pointer transition-all text-center relative group ${formData.selectedPlan === plan.id ? 'border-orange-500 bg-orange-50/20 shadow-2xl scale-[1.02]' : 'border-gray-50 bg-white hover:border-gray-200'}`}>
                    <div className={`w-16 h-16 rounded-3xl flex items-center justify-center mx-auto mb-8 transition-all ${formData.selectedPlan === plan.id ? 'bg-orange-500 text-white shadow-xl shadow-orange-500/20' : 'bg-gray-50 text-gray-300'}`}><plan.icon size={28} /></div>
                    <h3 className="text-[11px] font-black uppercase tracking-widest text-[#2E2E2E]">{plan.label}</h3>
                    <p className="text-3xl font-black mt-5 text-[#2E2E2E] tracking-tighter">{plan.price}</p>
                    <p className="text-[9px] font-bold text-gray-400 mt-5 uppercase leading-relaxed">{plan.desc}</p>
                    {formData.selectedPlan === plan.id && <div className="absolute top-6 right-6 text-orange-500"><CheckCircle2 size={24} /></div>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-12 animate-premium">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div className="bg-[#2E2E2E] p-12 rounded-[3.5rem] text-white shadow-2xl relative overflow-hidden group">
                  <div className="relative z-10">
                    <div className="flex items-center gap-4 mb-10">
                      <div className="w-12 h-12 bg-orange-500 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-orange-500/20"><CreditCard size={24} /></div>
                      <h4 className="text-[11px] font-black uppercase tracking-[0.2em]">Transferência Direta</h4>
                    </div>
                    <div className="space-y-8">
                      <div>
                        <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">IBAN BAI Angola</span>
                        <p className="text-xl font-mono font-bold mt-2 select-all tracking-tighter">0040 0000 6280 6554 101 92</p>
                      </div>
                      <div>
                        <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Multicaixa Express</span>
                        <p className="text-xl font-bold mt-2 select-all tracking-tighter">959 492 748</p>
                      </div>
                    </div>
                  </div>
                  <div className="absolute -bottom-16 -right-16 w-48 h-48 bg-orange-500/10 rounded-full blur-3xl transition-all duration-1000 group-hover:scale-150"></div>
                </div>

                <div className="space-y-4">
                   <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Comprovativo de Pagamento</label>
                   <input type="file" ref={proofInputRef} onChange={e => handleFileUpload(e, 'proof')} accept="image/*,.pdf,.docx" className="hidden" />
                   <div onClick={() => proofInputRef.current?.click()} className={`aspect-video w-full border-2 border-dashed rounded-[3.5rem] flex flex-col items-center justify-center text-center cursor-pointer transition-all hover:scale-[1.01] ${proofName ? 'border-green-500 bg-green-50/10' : 'border-gray-200 bg-gray-50 hover:border-orange-500 shadow-inner'}`}>
                    {proofName ? (
                      <div className="text-center p-10">
                        <FileText size={48} className="text-green-500 mx-auto mb-5" />
                        <span className="text-xs font-black text-[#2E2E2E] block truncate max-w-[250px]">{proofName}</span>
                        <span className="text-[10px] font-bold text-green-600 mt-3 uppercase tracking-widest">Ficheiro Anexado</span>
                      </div>
                    ) : (
                      <>
                        <UploadIcon size={40} className="text-gray-300 mb-5" />
                        <span className="text-[11px] font-black uppercase tracking-widest text-gray-400">Anexar Ficheiro</span>
                        <p className="text-[9px] font-bold text-gray-300 mt-3 uppercase tracking-tighter">Foto, PDF ou DOCX</p>
                      </>
                    )}
                   </div>
                </div>
              </div>

              <div className="space-y-12 pt-12 border-t border-gray-100">
                <div className="space-y-5">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] flex items-center gap-3">
                    <PenTool size={18} className="text-[#2E2E2E]" /> Assinatura Digital
                  </label>
                  <input 
                    type="text" 
                    placeholder="Digita o seu nome completo para assinar juridicamente" 
                    value={formData.signature} 
                    onChange={e => setFormData({...formData, signature: e.target.value})} 
                    className="w-full px-10 py-6 bg-gray-50 rounded-[2.5rem] italic font-bold text-sm shadow-inner outline-none focus:bg-white focus:border-gray-100 transition-all" 
                  />
                </div>

                <label className="flex items-center gap-6 cursor-pointer p-8 bg-gray-50/50 rounded-[3rem] group transition-all" onClick={() => setFormData({...formData, termsAccepted: !formData.termsAccepted})}>
                  <div className={`w-10 h-10 rounded-2xl border-2 flex items-center justify-center transition-all ${formData.termsAccepted ? 'bg-orange-500 border-orange-500 text-white shadow-xl shadow-orange-500/20' : 'bg-white border-gray-200'}`}>
                    <Check size={22} strokeWidth={4} />
                  </div>
                  <div>
                    <span className="text-sm font-bold text-[#2E2E2E] group-hover:text-orange-600 transition-colors block leading-none">Concordo com os Termos da Stream Music Angola</span>
                    <p className="text-[10px] font-medium text-gray-400 mt-2">Declaro ser o titular absoluto dos direitos fonográficos.</p>
                  </div>
                </label>
              </div>
            </div>
          )}

        </div>
      </div>

      <div className="mt-12 flex items-center justify-between">
        <button onClick={prevStep} disabled={step === 1} className={`px-12 py-6 font-black text-xs uppercase tracking-widest transition-all ${step === 1 ? 'opacity-0 cursor-default' : 'text-gray-400 hover:text-black active:scale-95'}`}>Voltar</button>
        {step === 4 ? (
          <button onClick={handleFinalSubmit} className="px-20 py-7 bg-[#2E2E2E] text-white rounded-[2rem] font-black text-xs uppercase tracking-widest shadow-2xl hover:bg-black transform hover:-translate-y-1 active:scale-95 transition-all flex items-center gap-4">
            Distribuir Música <Check size={20} />
          </button>
        ) : (
          <button onClick={nextStep} className="px-20 py-7 bg-orange-500 text-white rounded-[2rem] font-black text-xs uppercase tracking-widest shadow-2xl hover:bg-orange-600 transform hover:-translate-y-1 active:scale-95 transition-all flex items-center gap-4">
            Próximo Passo <ArrowRight size={20} />
          </button>
        )}
      </div>
    </div>
  );
};

export default Upload;
