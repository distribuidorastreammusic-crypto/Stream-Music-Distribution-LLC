
import React, { useState } from 'react';
import { MessageSquare, Phone, HelpCircle, ChevronRight, ChevronDown, CheckCircle2, Loader2, ExternalLink, Send, X } from 'lucide-react';

interface SupportProps {
  onSubmitTicket: (subject: string, message: string) => void;
}

const Support: React.FC<SupportProps> = ({ onSubmitTicket }) => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [isOpeningTicket, setIsOpeningTicket] = useState(false);
  const [ticketSent, setTicketSent] = useState(false);
  const [showForm, setShowForm] = useState(false);
  
  // Estados do formulário
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  const faqs = [
    { q: "Quanto tempo demora para a música estar nas lojas?", a: "Geralmente, o processo leva entre 48 horas a 7 dias úteis após a aprovação da nossa equipe interna em Luanda." },
    { q: "Como recebo os meus royalties em Angola?", a: "Os pagamentos são processados via Transferência Bancária Nacional para contas BAI, BFA, BIC ou via Multicaixa Express. Os royalties são pagos trimestralmente." },
    { q: "O que é ISRC e UPC?", a: "ISRC é o código de identificação da música (sua 'impressão digital'). UPC é o código de barras do álbum ou single completo. A Stream Music gera ambos gratuitamente para si." },
    { q: "Quais formatos de áudio são aceitos?", a: "Aceitamos apenas arquivos WAV (16 ou 24 bits) ou FLAC. Não aceitamos MP3 para distribuição profissional devido à perda de qualidade." },
  ];

  const handleSendTicket = () => {
    if (!subject || !message) {
      return alert("Por favor, preencha o assunto e a mensagem do seu ticket.");
    }

    setIsOpeningTicket(true);
    
    // Simulação de delay de rede
    setTimeout(() => {
      onSubmitTicket(subject, message);
      
      setIsOpeningTicket(false);
      setTicketSent(true);
      setShowForm(false);
      
      // Reseta formulário
      setSubject('');
      setMessage('');

      setTimeout(() => setTicketSent(false), 5000);
    }, 1500);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-16 animate-premium">
      <header className="text-center space-y-4">
        <span className="text-[10px] font-black text-orange-500 uppercase tracking-[0.4em] block">Central de Ajuda</span>
        <h1 className="text-5xl md:text-6xl font-black text-[#2E2E2E] tracking-tighter">Como podemos ajudar?</h1>
        <p className="text-gray-400 text-lg font-medium max-w-2xl mx-auto">Suporte especializado para artistas e labels angolanas em escala global.</p>
      </header>

      {/* Canais de Contacto */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <a 
          href="https://wa.me/244957729023" 
          target="_blank" 
          rel="noreferrer"
          className="bg-white p-12 rounded-[3.5rem] shadow-2xl shadow-gray-200/40 border border-gray-100 flex flex-col items-center text-center space-y-6 hover:shadow-orange-500/10 hover:-translate-y-2 transition-all duration-500 group"
        >
          <div className="w-20 h-20 bg-green-50 text-green-600 rounded-3xl flex items-center justify-center group-hover:scale-110 transition-transform shadow-inner">
            <Phone size={36} />
          </div>
          <div className="space-y-2">
            <h3 className="text-xl font-black text-[#2E2E2E] uppercase tracking-tighter">WhatsApp Direct</h3>
            <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Atendimento em Luanda</p>
          </div>
          <p className="text-sm text-gray-500 font-medium leading-relaxed px-4">Fale em tempo real com os nossos especialistas sobre aprovações, pagamentos e suporte técnico.</p>
          <div className="flex items-center gap-2 px-8 py-4 bg-[#2E2E2E] text-white rounded-2xl text-[10px] font-black uppercase tracking-widest group-hover:bg-green-600 transition-colors">
            Contactar agora <ExternalLink size={14} />
          </div>
        </a>

        <div className={`bg-white p-12 rounded-[3.5rem] shadow-2xl shadow-gray-200/40 border border-gray-100 flex flex-col items-center text-center space-y-6 transition-all duration-500 ${showForm ? 'ring-2 ring-orange-500/20 md:col-span-1' : 'hover:-translate-y-2'}`}>
          <div className="w-20 h-20 bg-orange-50 text-orange-600 rounded-3xl flex items-center justify-center transition-transform shadow-inner">
            <MessageSquare size={36} />
          </div>
          
          {!showForm ? (
            <>
              <div className="space-y-2">
                <h3 className="text-xl font-black text-[#2E2E2E] uppercase tracking-tighter">Ticket de Suporte</h3>
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Registo Oficial</p>
              </div>
              <p className="text-sm text-gray-500 font-medium leading-relaxed px-4">Abra um chamado oficial para questões complexas ou problemas na distribuição das suas músicas.</p>
              
              <button 
                onClick={() => setShowForm(true)}
                className={`w-full max-w-[280px] px-8 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-3 bg-[#2E2E2E] text-white hover:bg-orange-600`}
              >
                Abrir Ticket Oficial
              </button>
            </>
          ) : (
            <div className="w-full space-y-5 animate-premium">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Novo Ticket Administrativo</span>
                <button onClick={() => setShowForm(false)} className="text-gray-300 hover:text-red-500 transition-colors"><X size={18} /></button>
              </div>
              
              <div className="space-y-2 text-left">
                <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-4">Assunto do Problema</label>
                <input 
                  type="text" 
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Ex: Erro no upload de áudio" 
                  className="w-full px-6 py-4 bg-gray-50 rounded-2xl border-transparent focus:bg-white focus:border-orange-100 outline-none font-bold text-xs transition-all shadow-inner"
                />
              </div>

              <div className="space-y-2 text-left">
                <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-4">Mensagem Detalhada</label>
                <textarea 
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Explique o que aconteceu da forma mais detalhada possível..." 
                  className="w-full px-6 py-4 bg-gray-50 rounded-[1.5rem] border-transparent focus:bg-white focus:border-orange-100 outline-none font-bold text-xs transition-all shadow-inner resize-none custom-scrollbar"
                />
              </div>

              <button 
                onClick={handleSendTicket}
                disabled={isOpeningTicket}
                className="w-full py-5 bg-[#2E2E2E] text-white rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3 hover:bg-black active:scale-95 shadow-xl shadow-black/5"
              >
                {isOpeningTicket ? (
                  <><Loader2 size={16} className="animate-spin" /> Enviando ao Painel...</>
                ) : (
                  <>Enviar Ticket <Send size={14} /></>
                )}
              </button>
            </div>
          )}

          {ticketSent && (
            <div className="flex items-center gap-3 text-green-600 animate-bounce mt-4">
              <CheckCircle2 size={18} />
              <span className="text-[10px] font-black uppercase tracking-widest">Ticket enviado com sucesso!</span>
            </div>
          )}
        </div>
      </div>

      {/* FAQ Section */}
      <div className="bg-white rounded-[4rem] shadow-2xl shadow-gray-200/30 border border-gray-50 overflow-hidden">
        <div className="p-10 md:p-14 border-b border-gray-50 bg-gray-50/30">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-orange-500 shadow-sm">
              <HelpCircle size={24} />
            </div>
            <div>
              <h2 className="text-2xl font-black text-[#2E2E2E] tracking-tighter">Perguntas Frequentes</h2>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-1">FAQ da Stream Music Angola</p>
            </div>
          </div>
        </div>
        <div className="divide-y divide-gray-50">
          {faqs.map((faq, idx) => (
            <div 
              key={idx} 
              className={`transition-all duration-300 ${openFaq === idx ? 'bg-orange-50/30' : 'hover:bg-gray-50'}`}
            >
              <button 
                onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                className="w-full px-10 py-8 flex items-center justify-between group"
              >
                <h4 className={`text-sm md:text-base font-black transition-colors text-left pr-6 ${openFaq === idx ? 'text-orange-600' : 'text-[#2E2E2E] group-hover:text-orange-500'}`}>
                  {faq.q}
                </h4>
                <div className={`transition-transform duration-300 ${openFaq === idx ? 'rotate-180 text-orange-500' : 'text-gray-300'}`}>
                  {openFaq === idx ? <ChevronDown size={22} /> : <ChevronRight size={22} />}
                </div>
              </button>
              {openFaq === idx && (
                <div className="px-10 pb-10 animate-premium">
                  <p className="text-gray-500 text-sm md:text-base leading-relaxed font-medium">
                    {faq.a}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <footer className="text-center py-10">
        <p className="text-[10px] font-bold text-gray-300 uppercase tracking-[0.4em]">Horário de Atendimento: Seg-Sex • 08:00 - 18:00 (WAT)</p>
      </footer>
    </div>
  );
};

export default Support;
