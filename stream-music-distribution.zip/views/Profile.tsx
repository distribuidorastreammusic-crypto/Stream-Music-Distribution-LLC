
import React, { useState, useRef } from 'react';
import { Camera, Mail, Instagram, Facebook, Phone, MapPin, Check, Loader2 } from 'lucide-react';
import { PROVINCES } from '../constants';

const Profile: React.FC = () => {
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [profile, setProfile] = useState({
    stageName: 'Dji Tafinha',
    email: 'dji@galaxia.ao',
    bio: 'Nascido em Luanda, Dji Tafinha é um dos maiores nomes da cena Hip Hop e Pop angolana. Produtor, compositor e CEO da Galáxia, tem moldado o som da nova geração de artistas em Angola.',
    province: 'Luanda',
    whatsapp: '957729023',
    facebook: 'djitafinhaoficial',
    instagram: 'djitafinha_original',
    avatar: 'https://picsum.photos/seed/artist/200/200'
  });

  const handleSave = () => {
    setIsSaving(true);
    // Simulação de chamada de API
    setTimeout(() => {
      setIsSaving(false);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
      console.log('Dados guardados:', profile);
    }, 1500);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setProfile({ ...profile, avatar: url });
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10 animate-premium">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-5xl font-black text-[#2E2E2E] tracking-tighter">Meu Perfil</h1>
          <p className="text-gray-400 mt-2 text-xs font-bold uppercase tracking-widest">Identidade Artística e Gestão de Marca</p>
        </div>
        
        {saveSuccess && (
          <div className="flex items-center gap-2 px-6 py-3 bg-green-50 text-green-600 rounded-2xl border border-green-100 animate-premium">
            <Check size={18} strokeWidth={3} />
            <span className="text-[10px] font-black uppercase tracking-widest">Alterações Guardadas!</span>
          </div>
        )}
      </header>

      <div className="bg-white rounded-[3.5rem] shadow-2xl shadow-gray-200/40 border border-gray-100 overflow-hidden">
        {/* Header Cover */}
        <div className="h-56 bg-[#2E2E2E] relative overflow-hidden">
          <div className="absolute inset-0 opacity-20">
             <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-orange-500 via-transparent to-transparent"></div>
          </div>
          
          <div className="absolute -bottom-20 left-12 flex items-end gap-6">
            <div className="relative group">
              <div className="w-40 h-40 rounded-[2.5rem] border-8 border-white overflow-hidden bg-gray-100 shadow-2xl transition-transform duration-500 group-hover:scale-[1.02]">
                <img src={profile.avatar} alt="Avatar" className="w-full h-full object-cover" />
              </div>
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="absolute inset-0 bg-black/40 text-white flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 rounded-[2rem] backdrop-blur-sm"
              >
                <Camera size={28} />
                <span className="text-[8px] font-black uppercase mt-2 tracking-widest">Alterar Foto</span>
              </button>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileChange} 
                className="hidden" 
                accept="image/*" 
              />
            </div>
          </div>
        </div>

        <div className="pt-24 p-12 space-y-12">
          {/* Form Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="space-y-3">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-2">Nome Artístico / Stage Name</label>
              <input 
                type="text" 
                value={profile.stageName} 
                onChange={(e) => setProfile({...profile, stageName: e.target.value})}
                className="w-full px-8 py-4 bg-gray-50 rounded-2xl border-transparent focus:bg-white focus:border-gray-200 outline-none font-bold text-sm transition-all shadow-inner" 
              />
            </div>
            
            <div className="space-y-3">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-2">E-mail de Contacto Profissional</label>
              <div className="relative">
                <Mail className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                <input 
                  type="email" 
                  value={profile.email} 
                  onChange={(e) => setProfile({...profile, email: e.target.value})}
                  className="w-full pl-16 pr-8 py-4 bg-gray-50 rounded-2xl border-transparent focus:bg-white focus:border-gray-200 outline-none font-bold text-sm transition-all shadow-inner" 
                />
              </div>
            </div>

            <div className="space-y-3 md:col-span-2">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-2">Biografia Curta</label>
              <textarea 
                rows={4} 
                value={profile.bio} 
                onChange={(e) => setProfile({...profile, bio: e.target.value})}
                className="w-full px-8 py-5 bg-gray-50 rounded-[2rem] border-transparent focus:bg-white focus:border-gray-200 outline-none font-bold text-sm transition-all shadow-inner resize-none custom-scrollbar"
              />
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-2">Província de Residência</label>
              <div className="relative">
                <MapPin className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                <select 
                  value={profile.province}
                  onChange={(e) => setProfile({...profile, province: e.target.value})}
                  className="w-full pl-16 pr-8 py-4 bg-gray-50 rounded-2xl border-transparent outline-none font-bold text-sm transition-all shadow-inner bg-white cursor-pointer"
                >
                  {PROVINCES.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-2">WhatsApp (+244)</label>
              <div className="relative">
                <Phone className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                <input 
                  type="text" 
                  value={profile.whatsapp} 
                  onChange={(e) => setProfile({...profile, whatsapp: e.target.value})}
                  className="w-full pl-16 pr-8 py-4 bg-gray-50 rounded-2xl border-transparent focus:bg-white focus:border-gray-200 outline-none font-bold text-sm transition-all shadow-inner" 
                />
              </div>
            </div>
          </div>

          {/* Social Links */}
          <div className="space-y-8 pt-8 border-t border-gray-50">
            <h3 className="text-[11px] font-black text-[#2E2E2E] uppercase tracking-[0.3em]">Canais de Divulgação Social</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-center gap-4 group">
                <div className="p-4 bg-blue-50 text-blue-600 rounded-2xl group-hover:scale-110 transition-transform">
                  <Facebook size={22} />
                </div>
                <div className="flex-1 space-y-1">
                  <span className="text-[9px] font-black text-gray-300 uppercase tracking-widest">Facebook ID</span>
                  <input 
                    type="text" 
                    value={profile.facebook}
                    onChange={(e) => setProfile({...profile, facebook: e.target.value})}
                    placeholder="ex: djitafinhaoficial" 
                    className="w-full px-6 py-3 bg-gray-50 rounded-xl border-transparent focus:bg-white focus:border-blue-100 outline-none font-bold text-xs transition-all" 
                  />
                </div>
              </div>
              
              <div className="flex items-center gap-4 group">
                <div className="p-4 bg-pink-50 text-pink-600 rounded-2xl group-hover:scale-110 transition-transform">
                  <Instagram size={22} />
                </div>
                <div className="flex-1 space-y-1">
                  <span className="text-[9px] font-black text-gray-300 uppercase tracking-widest">Instagram User</span>
                  <input 
                    type="text" 
                    value={profile.instagram}
                    onChange={(e) => setProfile({...profile, instagram: e.target.value})}
                    placeholder="ex: djitafinha_original" 
                    className="w-full px-6 py-3 bg-gray-50 rounded-xl border-transparent focus:bg-white focus:border-pink-100 outline-none font-bold text-xs transition-all" 
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row items-center justify-between pt-10 border-t border-gray-50 gap-6">
            <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest text-center sm:text-left">
              Última atualização em: <span className="text-[#2E2E2E]">24 de Outubro, 2023</span>
            </p>
            <button 
              onClick={handleSave}
              disabled={isSaving}
              className={`min-w-[240px] px-12 py-6 rounded-[1.5rem] font-black text-[10px] uppercase tracking-[0.2em] shadow-2xl transition-all flex items-center justify-center gap-3 active:scale-95 ${
                isSaving 
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
                : 'bg-[#2E2E2E] text-white hover:bg-black shadow-black/10'
              }`}
            >
              {isSaving ? (
                <>
                  <Loader2 size={18} className="animate-spin" />
                  A Guardar...
                </>
              ) : (
                <>
                  Guardar Alterações <Check size={18} strokeWidth={3} />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
